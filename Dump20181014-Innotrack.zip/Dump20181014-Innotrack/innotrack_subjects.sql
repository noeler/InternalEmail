CREATE DATABASE  IF NOT EXISTS `innotrack` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `innotrack`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: innotrack
-- ------------------------------------------------------
-- Server version	5.6.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(255) DEFAULT NULL,
  `subject_type` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'Art and Design','Foundation','2013-08-03 21:46:22','2013-08-31 20:13:28'),(2,'Creative Development','Foundation','2013-08-31 20:14:18','2013-08-31 20:14:18'),(3,'Design and Technology','Foundation','2013-08-31 20:14:54','2013-08-31 20:14:54'),(4,'English/LLC-Oracy','Core','2013-08-31 20:15:32','2013-08-31 20:15:32'),(5,'English/LLC-Reading','Core','2013-08-31 20:16:06','2013-08-31 20:16:06'),(6,'English/LLC-Writing','Core','2013-08-31 20:16:30','2013-08-31 20:16:30'),(7,'Geography','Foundation','2013-08-31 20:16:56','2013-08-31 20:16:56'),(8,'History','Foundation','2013-08-31 20:17:21','2013-08-31 20:17:21'),(9,'Information Technology','Foundation','2013-08-31 20:17:45','2013-08-31 20:17:45'),(10,'Knowledge and Understanding of the World','Foundation','2013-08-31 20:18:13','2013-08-31 20:18:13'),(11,'Maths/Mathematical Development','Core','2013-08-31 20:18:54','2013-08-31 20:18:54'),(12,'Music','Foundation','2013-08-31 20:19:28','2013-08-31 20:19:28'),(13,'Physical Development','Foundation','2013-08-31 20:19:59','2013-08-31 20:19:59'),(14,'Physical Education','Foundation','2013-08-31 20:20:31','2013-08-31 20:20:31'),(15,'PSD,WB & CD','Core','2013-08-31 20:21:04','2013-08-31 20:21:04'),(16,'Religious Education','Core','2013-08-31 20:21:39','2013-08-31 20:21:39'),(17,'Science','Core','2013-08-31 20:21:56','2013-08-31 20:21:56'),(18,'Welsh-Oracy','Core','2013-08-31 20:22:22','2013-08-31 20:22:22'),(19,'Welsh-Reading','Core','2013-08-31 20:23:03','2013-08-31 20:23:03'),(20,'Welsh-Writing','Core','2013-08-31 20:23:34','2013-08-31 20:23:34');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-14 19:54:26
