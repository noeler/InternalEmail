CREATE DATABASE  IF NOT EXISTS `innotrack` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `innotrack`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: innotrack
-- ------------------------------------------------------
-- Server version	5.6.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `login` varchar(255) DEFAULT NULL,
  `crypted_password` varchar(255) NOT NULL,
  `password_salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `registration_code` varchar(255) NOT NULL,
  `persistence_token` varchar(255) NOT NULL,
  `single_access_token` varchar(255) NOT NULL,
  `perishable_token` varchar(255) NOT NULL,
  `login_count` int(11) NOT NULL DEFAULT '0',
  `failed_login_count` int(11) NOT NULL DEFAULT '0',
  `last_request_at` datetime DEFAULT NULL,
  `current_login_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `current_login_ip` varchar(255) DEFAULT NULL,
  `last_login_ip` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `roles` varchar(255) DEFAULT '--- []',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'test',NULL,'400$8$14$288ba3225ba63dde$c9f2f5f1d83d2933f3b6d8b2700b8399025afb3b25f509afd3e3b9148ff2342e','ZbXII9ofMLeJKiD5FUZI','tester@test.com','school','e69bb9bd9473fe123ffeb5f57514527a5807eb2bbc8b5ff14173c93aca8d464d19e1d14d55c8e9150e747c9b7908ccab438883cd6c0f3453ef88fdd8400fc061','OYLA7NPgz04b4nunBkqN','Aknre82BKNJpaIolA9Vd',135,0,'2015-02-10 00:52:34','2015-02-10 00:31:49','2015-02-08 23:27:58','127.0.0.1','127.0.0.1','2013-08-03 21:42:07','2015-02-10 00:52:34','---\n- user\n- admin\n'),(2,'Louise Muteham',NULL,'b1a48908f56c9597184e89511987ac031dceeefc9aaf711d0ded6dbec57f3ee662a021edc7b3997b4106a578f596cbc9110b16f24ca2e3efa0ed1fd0630ef7bc','O9CytAqhOoq8XnWPAFtt','lmuteham@hotmail.co.uk','school','b3d5866f46f7e526469d8dc9347f5ac3b22310c08c8f1c6ae9f243d2c9d11f8e39fb4228d6aa73b4c3d423c7d403d9b1f2d96deda868d952513aea1fd61c2325','3hSbwQXCEGvxt4VfLDGC','2CfDE2EOvNuJ38uPrxzU',12,1,'2013-09-08 00:41:16','2013-09-08 00:12:25','2013-09-02 21:23:16','127.0.0.1','81.130.69.206','2013-08-31 20:40:00','2014-04-05 11:17:37','---\n- user\n- admin\n'),(3,'user',NULL,'9d410f849c982611d39a955637899fbe409fff0ad630328d315c2e38a53500d1b4905e75fdd662ff3c019657f7515d2b1d1d4c4f75647ece35962233192f928c','YDoXXfu3OM4w9jw7xj','user@test.com','school','53a969c3ddf425f569bf293637e8c20c761c7eaec184fdb3bc09da5f14b767c418050ce625dc39bff4bd8b74f25cd7289c3abe71e9109e5da7bb30c6bc0d02e0','CVyUxHHGU1EcQN39k','gxIyKz2lrbkdESOb2TF',1,1,'2014-02-17 22:27:40','2014-02-17 22:25:10',NULL,'127.0.0.1',NULL,'2014-02-17 22:23:32','2014-04-05 11:17:01','---\n- user\n'),(4,'test2',NULL,'400$8$6$7e8321f526456e7c$b45b3f20f7889b3c6cabcb14a537d9d522363c34c0749ec9ee3c24035758e745','dTDH8THDsuqzKnQaP9O','test2@tester.com','school','b65687e593f1a7917edeee59453f92e8b3f3631674c361d96d21a969582b0421d4e4b3fd4ce5c93adfa7f3b62d2feba022ebb962409f459c1e8a435d54a6d2da','2f7xaug2PMTbl3pl5F0b','PdV5azZ0AJkIEibQYZL',2,0,'2014-04-05 11:23:31','2014-04-05 11:22:58','2014-04-05 11:22:05','127.0.0.1','127.0.0.1','2014-04-05 11:22:05','2014-04-05 11:23:31','---\n- user\n');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-14 19:54:27
