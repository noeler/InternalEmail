CREATE DATABASE  IF NOT EXISTS `innotrack` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `innotrack`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: innotrack
-- ------------------------------------------------------
-- Server version	5.6.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `registration_groups`
--

DROP TABLE IF EXISTS `registration_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registration_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registrationgroup` varchar(255) DEFAULT NULL,
  `teacher` varchar(255) DEFAULT NULL,
  `graduation_year` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration_groups`
--

LOCK TABLES `registration_groups` WRITE;
/*!40000 ALTER TABLE `registration_groups` DISABLE KEYS */;
INSERT INTO `registration_groups` VALUES (1,'6SJ','SJ','2014','2013-09-08 22:07:53','2013-09-08 22:07:53'),(2,'6AP','AP','2014','2013-09-08 22:07:53','2013-09-08 22:07:53'),(3,'SLM','LM','2015','2013-09-08 22:07:53','2013-09-08 22:07:53'),(4,'5MS','MS','2015','2013-09-08 22:07:53','2013-09-08 22:07:53'),(5,'4LO','LO','2016','2013-09-08 22:07:53','2013-09-08 22:07:53'),(6,'4SM','SM','2016','2013-09-08 22:07:53','2013-09-08 22:07:53'),(7,'3CG','CG','2017','2013-09-08 22:07:53','2013-09-08 22:07:53'),(8,'3BG','BB.BG','2017','2013-09-08 22:07:53','2013-09-08 22:07:53'),(9,'2CT','CT','2018','2013-09-08 22:07:53','2013-09-08 22:07:53'),(10,'2VS','VS','2018','2013-09-08 22:07:53','2013-09-08 22:07:53'),(11,'1KL','KL','2019','2013-09-08 22:07:53','2013-09-08 22:07:53'),(12,'1LWK','LWK','2019','2013-09-08 22:07:53','2013-09-08 22:07:53');
/*!40000 ALTER TABLE `registration_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-14 19:54:22
