require 'test_helper'

class FieldNotesControllerTest < ActionController::TestCase
  setup do
    @field_note = field_notes(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:field_notes)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create field_note" do
    assert_difference('FieldNote.count') do
      post :create, field_note: @field_note.attributes
    end

    assert_redirected_to field_note_path(assigns(:field_note))
  end

  test "should show field_note" do
    get :show, id: @field_note
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @field_note
    assert_response :success
  end

  test "should update field_note" do
    put :update, id: @field_note, field_note: @field_note.attributes
    assert_redirected_to field_note_path(assigns(:field_note))
  end

  test "should destroy field_note" do
    assert_difference('FieldNote.count', -1) do
      delete :destroy, id: @field_note
    end

    assert_redirected_to field_notes_path
  end
end
