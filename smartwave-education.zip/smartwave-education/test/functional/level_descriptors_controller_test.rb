require 'test_helper'

class LevelDescriptorsControllerTest < ActionController::TestCase
  setup do
    @level_descriptor = level_descriptors(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:level_descriptors)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create level_descriptor" do
    assert_difference('LevelDescriptor.count') do
      post :create, level_descriptor: @level_descriptor.attributes
    end

    assert_redirected_to level_descriptor_path(assigns(:level_descriptor))
  end

  test "should show level_descriptor" do
    get :show, id: @level_descriptor
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @level_descriptor
    assert_response :success
  end

  test "should update level_descriptor" do
    put :update, id: @level_descriptor, level_descriptor: @level_descriptor.attributes
    assert_redirected_to level_descriptor_path(assigns(:level_descriptor))
  end

  test "should destroy level_descriptor" do
    assert_difference('LevelDescriptor.count', -1) do
      delete :destroy, id: @level_descriptor
    end

    assert_redirected_to level_descriptors_path
  end
end
