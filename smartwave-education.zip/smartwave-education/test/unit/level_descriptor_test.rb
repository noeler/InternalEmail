require 'test_helper'

class LevelDescriptorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
