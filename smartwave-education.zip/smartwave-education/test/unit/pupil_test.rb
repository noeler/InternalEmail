require 'test_helper'

class PupilTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
