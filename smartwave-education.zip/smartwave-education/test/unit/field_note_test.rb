require 'test_helper'

class FieldNoteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
