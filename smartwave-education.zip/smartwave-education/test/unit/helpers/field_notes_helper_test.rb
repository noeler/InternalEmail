require 'test_helper'

class FieldNotesHelperTest < ActionView::TestCase
end
