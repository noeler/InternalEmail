require 'test_helper'

class LevelDescriptorsHelperTest < ActionView::TestCase
end
