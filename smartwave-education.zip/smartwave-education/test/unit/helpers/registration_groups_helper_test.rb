require 'test_helper'

class RegistrationGroupsHelperTest < ActionView::TestCase
end
