require 'test_helper'

class PupilsHelperTest < ActionView::TestCase
end
