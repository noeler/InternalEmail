DROP TABLE IF EXISTS "field_notes";
CREATE TABLE "field_notes" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "pupil" varchar(255), "subject" varchar(255), "level_descriptor" varchar(255), "statement" varchar(255), "red" varchar(255), "yellow" varchar(255), "green" varchar(255), "comment" varchar(255), "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);
INSERT INTO "field_notes" VALUES(15,'1','1','1','','4','R','3','ggfhfghf
2013-08-13T22:13:27+00:00

Comment 1
2013-08-13T22:29:15+00:00','2013-08-04 21:43:09.818766','2013-08-13 21:29:15.673728');
INSERT INTO "field_notes" VALUES(16,'1','1','2',NULL,'R','6','1','sdfsdff
2013-08-13T22:23:38+00:00

Comment 22013-08-13T22:29:24+00:00','2013-08-09 20:38:48.400181','2013-08-13 21:29:24.009204');
INSERT INTO "field_notes" VALUES(17,'1','1','3',NULL,'R','R','2',NULL,'2013-08-31 22:34:49.247400','2013-08-31 22:34:49.247400');
INSERT INTO "field_notes" VALUES(18,'1','1','4',NULL,'1',NULL,NULL,NULL,'2013-08-31 22:34:49.309800','2013-08-31 22:34:49.309800');
INSERT INTO "field_notes" VALUES(19,'1','1','5',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.214600','2013-08-31 22:34:50.214600');
INSERT INTO "field_notes" VALUES(20,'1','1','6',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.292600','2013-08-31 22:34:50.292600');
INSERT INTO "field_notes" VALUES(21,'1','1','7',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.355000','2013-08-31 22:34:50.355000');
INSERT INTO "field_notes" VALUES(22,'1','1','8',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.417400','2013-08-31 22:34:50.417400');
INSERT INTO "field_notes" VALUES(23,'1','1','13',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.573400','2013-08-31 22:34:50.573400');
INSERT INTO "field_notes" VALUES(24,'1','1','12',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.635800','2013-08-31 22:34:50.635800');
INSERT INTO "field_notes" VALUES(25,'1','1','15',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.698200','2013-08-31 22:34:50.698200');
INSERT INTO "field_notes" VALUES(26,'1','1','16',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.776200','2013-08-31 22:34:50.776200');
INSERT INTO "field_notes" VALUES(27,'1','1','17',NULL,'0',NULL,NULL,NULL,'2013-08-31 22:34:50.823000','2013-08-31 22:34:50.823000');
INSERT INTO "field_notes" VALUES(28,'1','1','18',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:50.885400','2013-08-31 22:34:50.885400');
INSERT INTO "field_notes" VALUES(29,'1','1','19',NULL,NULL,NULL,NULL,'2013-09-01T00:00:40+00:00','2013-08-31 22:34:50.963400','2013-08-31 23:00:40.012200');
INSERT INTO "field_notes" VALUES(30,'1','1','20',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:51.025800','2013-08-31 22:34:51.025800');
INSERT INTO "field_notes" VALUES(31,'1','1','21',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:51.166200','2013-08-31 22:34:51.166200');
INSERT INTO "field_notes" VALUES(32,'1','1','22',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:51.228600','2013-08-31 22:34:51.228600');
INSERT INTO "field_notes" VALUES(33,'1','1','9',NULL,'3','4','4',NULL,'2013-08-31 22:34:51.306600','2013-08-31 22:34:51.306600');
INSERT INTO "field_notes" VALUES(34,'1','1','10',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:51.369000','2013-08-31 22:34:51.369000');
INSERT INTO "field_notes" VALUES(35,'1','1','11',NULL,NULL,NULL,NULL,'null2013-09-01T11:29:22+00:00','2013-08-31 22:34:51.415800','2013-09-01 10:29:22.714200');
INSERT INTO "field_notes" VALUES(36,'1','1','14',NULL,NULL,NULL,NULL,NULL,'2013-08-31 22:34:51.478200','2013-08-31 22:34:51.478200');
INSERT INTO "field_notes" VALUES(37,'1','4','45',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:46.623000','2013-09-02 19:37:46.623000');
INSERT INTO "field_notes" VALUES(38,'1','4','46',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:46.701000','2013-09-02 19:37:46.701000');
INSERT INTO "field_notes" VALUES(39,'1','4','47',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:46.825800','2013-09-02 19:37:46.825800');
INSERT INTO "field_notes" VALUES(40,'1','4','48',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:46.888200','2013-09-02 19:37:46.888200');
INSERT INTO "field_notes" VALUES(41,'1','4','49',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:46.966200','2013-09-02 19:37:46.966200');
INSERT INTO "field_notes" VALUES(42,'1','4','51',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.044200','2013-09-02 19:37:47.044200');
INSERT INTO "field_notes" VALUES(43,'1','4','50',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.122200','2013-09-02 19:37:47.122200');
INSERT INTO "field_notes" VALUES(44,'1','4','52',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.200200','2013-09-02 19:37:47.200200');
INSERT INTO "field_notes" VALUES(45,'1','4','53',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.247000','2013-09-02 19:37:47.247000');
INSERT INTO "field_notes" VALUES(46,'1','4','54',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.340600','2013-09-02 19:37:47.340600');
INSERT INTO "field_notes" VALUES(47,'1','4','55',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.418600','2013-09-02 19:37:47.418600');
INSERT INTO "field_notes" VALUES(48,'1','4','56',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.465400','2013-09-02 19:37:47.465400');
INSERT INTO "field_notes" VALUES(49,'1','4','57',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.512200','2013-09-02 19:37:47.512200');
INSERT INTO "field_notes" VALUES(50,'1','4','58',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.590200','2013-09-02 19:37:47.590200');
INSERT INTO "field_notes" VALUES(51,'1','4','59',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.637000','2013-09-02 19:37:47.637000');
INSERT INTO "field_notes" VALUES(52,'1','4','60',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.699400','2013-09-02 19:37:47.699400');
INSERT INTO "field_notes" VALUES(53,'1','4','61',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.777400','2013-09-02 19:37:47.777400');
INSERT INTO "field_notes" VALUES(54,'1','4','23',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.824200','2013-09-02 19:37:47.824200');
INSERT INTO "field_notes" VALUES(55,'1','4','24',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.902200','2013-09-02 19:37:47.902200');
INSERT INTO "field_notes" VALUES(56,'1','4','26',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:47.964600','2013-09-02 19:37:47.964600');
INSERT INTO "field_notes" VALUES(57,'1','4','27',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.027000','2013-09-02 19:37:48.027000');
INSERT INTO "field_notes" VALUES(58,'1','4','28',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.089400','2013-09-02 19:37:48.089400');
INSERT INTO "field_notes" VALUES(59,'1','4','29',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.151800','2013-09-02 19:37:48.151800');
INSERT INTO "field_notes" VALUES(60,'1','4','30',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.214200','2013-09-02 19:37:48.214200');
INSERT INTO "field_notes" VALUES(61,'1','4','31',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.292200','2013-09-02 19:37:48.292200');
INSERT INTO "field_notes" VALUES(62,'1','4','32',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.354600','2013-09-02 19:37:48.354600');
INSERT INTO "field_notes" VALUES(63,'1','4','33',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.463800','2013-09-02 19:37:48.463800');
INSERT INTO "field_notes" VALUES(64,'1','4','34',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.526200','2013-09-02 19:37:48.526200');
INSERT INTO "field_notes" VALUES(65,'1','4','35',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.604200','2013-09-02 19:37:48.604200');
INSERT INTO "field_notes" VALUES(66,'1','4','36',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.682200','2013-09-02 19:37:48.682200');
INSERT INTO "field_notes" VALUES(67,'1','4','37',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.760200','2013-09-02 19:37:48.760200');
INSERT INTO "field_notes" VALUES(68,'1','4','38',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.838200','2013-09-02 19:37:48.838200');
INSERT INTO "field_notes" VALUES(69,'1','4','39',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:48.931800','2013-09-02 19:37:48.931800');
INSERT INTO "field_notes" VALUES(70,'1','4','40',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:49.009800','2013-09-02 19:37:49.009800');
INSERT INTO "field_notes" VALUES(71,'1','4','41',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:49.056600','2013-09-02 19:37:49.056600');
INSERT INTO "field_notes" VALUES(72,'1','4','42',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:49.181400','2013-09-02 19:37:49.181400');
INSERT INTO "field_notes" VALUES(73,'1','4','43',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:49.228200','2013-09-02 19:37:49.228200');
INSERT INTO "field_notes" VALUES(74,'1','4','44',NULL,NULL,NULL,NULL,NULL,'2013-09-02 19:37:49.275000','2013-09-02 19:37:49.275000');
INSERT INTO "field_notes" VALUES(75,'1','6','104',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:15.730200','2013-09-02 20:44:15.730200');
INSERT INTO "field_notes" VALUES(76,'1','6','105',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:15.777000','2013-09-02 20:44:15.777000');
INSERT INTO "field_notes" VALUES(77,'1','6','106',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:15.823800','2013-09-02 20:44:15.823800');
INSERT INTO "field_notes" VALUES(78,'1','6','107',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:15.901800','2013-09-02 20:44:15.901800');
INSERT INTO "field_notes" VALUES(79,'1','6','108',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:15.948600','2013-09-02 20:44:15.948600');
INSERT INTO "field_notes" VALUES(80,'1','6','109',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.011000','2013-09-02 20:44:16.011000');
INSERT INTO "field_notes" VALUES(81,'1','6','110',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.042200','2013-09-02 20:44:16.042200');
INSERT INTO "field_notes" VALUES(82,'1','6','111',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.104600','2013-09-02 20:44:16.104600');
INSERT INTO "field_notes" VALUES(83,'1','6','112',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.213800','2013-09-02 20:44:16.213800');
INSERT INTO "field_notes" VALUES(84,'1','6','113',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.245000','2013-09-02 20:44:16.245000');
INSERT INTO "field_notes" VALUES(85,'1','6','114',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.307400','2013-09-02 20:44:16.307400');
INSERT INTO "field_notes" VALUES(86,'1','6','115',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.369800','2013-09-02 20:44:16.369800');
INSERT INTO "field_notes" VALUES(87,'1','6','116',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.432200','2013-09-02 20:44:16.432200');
INSERT INTO "field_notes" VALUES(88,'1','6','117',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.494600','2013-09-02 20:44:16.494600');
INSERT INTO "field_notes" VALUES(89,'1','6','118',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.541400','2013-09-02 20:44:16.541400');
INSERT INTO "field_notes" VALUES(90,'1','6','119',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.603800','2013-09-02 20:44:16.603800');
INSERT INTO "field_notes" VALUES(91,'1','6','120',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.666200','2013-09-02 20:44:16.666200');
INSERT INTO "field_notes" VALUES(92,'1','6','121',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.728600','2013-09-02 20:44:16.728600');
INSERT INTO "field_notes" VALUES(93,'1','6','122',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.775400','2013-09-02 20:44:16.775400');
INSERT INTO "field_notes" VALUES(94,'1','6','123',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.884600','2013-09-02 20:44:16.884600');
INSERT INTO "field_notes" VALUES(95,'1','6','124',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:16.947000','2013-09-02 20:44:16.947000');
INSERT INTO "field_notes" VALUES(96,'1','6','126',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.009400','2013-09-02 20:44:17.009400');
INSERT INTO "field_notes" VALUES(97,'1','6','127',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.056200','2013-09-02 20:44:17.056200');
INSERT INTO "field_notes" VALUES(98,'1','6','86',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.103000','2013-09-02 20:44:17.103000');
INSERT INTO "field_notes" VALUES(99,'1','6','87',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.165400','2013-09-02 20:44:17.165400');
INSERT INTO "field_notes" VALUES(100,'1','6','88',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.212200','2013-09-02 20:44:17.212200');
INSERT INTO "field_notes" VALUES(101,'1','6','89',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.259000','2013-09-02 20:44:17.259000');
INSERT INTO "field_notes" VALUES(102,'1','6','90',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.305800','2013-09-02 20:44:17.305800');
INSERT INTO "field_notes" VALUES(103,'1','6','91',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.383800','2013-09-02 20:44:17.383800');
INSERT INTO "field_notes" VALUES(104,'1','6','92',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.430600','2013-09-02 20:44:17.430600');
INSERT INTO "field_notes" VALUES(105,'1','6','93',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.539800','2013-09-02 20:44:17.539800');
INSERT INTO "field_notes" VALUES(106,'1','6','94',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.617800','2013-09-02 20:44:17.617800');
INSERT INTO "field_notes" VALUES(107,'1','6','95',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.695800','2013-09-02 20:44:17.695800');
INSERT INTO "field_notes" VALUES(108,'1','6','96',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.789400','2013-09-02 20:44:17.789400');
INSERT INTO "field_notes" VALUES(109,'1','6','97',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.851800','2013-09-02 20:44:17.851800');
INSERT INTO "field_notes" VALUES(110,'1','6','98',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:17.929800','2013-09-02 20:44:17.929800');
INSERT INTO "field_notes" VALUES(111,'1','6','99',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:18.007800','2013-09-02 20:44:18.007800');
INSERT INTO "field_notes" VALUES(112,'1','6','100',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:18.039000','2013-09-02 20:44:18.039000');
INSERT INTO "field_notes" VALUES(113,'1','6','101',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:18.085800','2013-09-02 20:44:18.085800');
INSERT INTO "field_notes" VALUES(114,'1','6','102',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:18.163800','2013-09-02 20:44:18.163800');
INSERT INTO "field_notes" VALUES(115,'1','6','103',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:44:18.210600','2013-09-02 20:44:18.210600');
INSERT INTO "field_notes" VALUES(116,'1','11','128',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.097400','2013-09-02 20:45:19.097400');
INSERT INTO "field_notes" VALUES(117,'1','11','129',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.144200','2013-09-02 20:45:19.144200');
INSERT INTO "field_notes" VALUES(118,'1','11','132',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.222200','2013-09-02 20:45:19.222200');
INSERT INTO "field_notes" VALUES(119,'1','11','130',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.284600','2013-09-02 20:45:19.284600');
INSERT INTO "field_notes" VALUES(120,'1','11','131',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.347000','2013-09-02 20:45:19.347000');
INSERT INTO "field_notes" VALUES(121,'1','11','133',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.409400','2013-09-02 20:45:19.409400');
INSERT INTO "field_notes" VALUES(122,'1','11','134',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.456200','2013-09-02 20:45:19.456200');
INSERT INTO "field_notes" VALUES(123,'1','11','135',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.518600','2013-09-02 20:45:19.518600');
INSERT INTO "field_notes" VALUES(124,'1','11','136',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.581000','2013-09-02 20:45:19.581000');
INSERT INTO "field_notes" VALUES(125,'1','11','137',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.627800','2013-09-02 20:45:19.627800');
INSERT INTO "field_notes" VALUES(126,'1','11','138',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.690200','2013-09-02 20:45:19.690200');
INSERT INTO "field_notes" VALUES(127,'1','11','139',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.752600','2013-09-02 20:45:19.752600');
INSERT INTO "field_notes" VALUES(128,'1','11','140',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.799400','2013-09-02 20:45:19.799400');
INSERT INTO "field_notes" VALUES(129,'1','11','141',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.908600','2013-09-02 20:45:19.908600');
INSERT INTO "field_notes" VALUES(130,'1','11','142',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:19.971000','2013-09-02 20:45:19.971000');
INSERT INTO "field_notes" VALUES(131,'1','11','143',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:20.017800','2013-09-02 20:45:20.017800');
INSERT INTO "field_notes" VALUES(132,'1','11','144',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:20.049000','2013-09-02 20:45:20.049000');
INSERT INTO "field_notes" VALUES(133,'1','11','145',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:20.111400','2013-09-02 20:45:20.111400');
INSERT INTO "field_notes" VALUES(134,'1','11','146',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:20.158200','2013-09-02 20:45:20.158200');
INSERT INTO "field_notes" VALUES(135,'1','11','147',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:20.236200','2013-09-02 20:45:20.236200');
INSERT INTO "field_notes" VALUES(136,'1','11','148',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:20.298600','2013-09-02 20:45:20.298600');
INSERT INTO "field_notes" VALUES(137,'1','11','149',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:20.361000','2013-09-02 20:45:20.361000');
INSERT INTO "field_notes" VALUES(138,'1','11','150',NULL,NULL,NULL,NULL,NULL,'2013-09-02 20:45:20.439000','2013-09-02 20:45:20.439000');
INSERT INTO "field_notes" VALUES(139,'1','1','128',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:51.260200','2013-09-05 22:18:51.260200');
INSERT INTO "field_notes" VALUES(140,'1','1','129',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:51.400600','2013-09-05 22:18:51.400600');
INSERT INTO "field_notes" VALUES(141,'1','1','130',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:51.478600','2013-09-05 22:18:51.478600');
INSERT INTO "field_notes" VALUES(142,'1','1','131',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:51.572200','2013-09-05 22:18:51.572200');
INSERT INTO "field_notes" VALUES(143,'1','1','132',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:51.712600','2013-09-05 22:18:51.712600');
INSERT INTO "field_notes" VALUES(144,'1','1','133',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:51.821800','2013-09-05 22:18:51.821800');
INSERT INTO "field_notes" VALUES(145,'1','1','134',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:51.899800','2013-09-05 22:18:51.899800');
INSERT INTO "field_notes" VALUES(146,'1','1','135',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:51.993400','2013-09-05 22:18:51.993400');
INSERT INTO "field_notes" VALUES(147,'1','1','136',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:52.087000','2013-09-05 22:18:52.087000');
INSERT INTO "field_notes" VALUES(148,'1','1','137',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:52.258600','2013-09-05 22:18:52.258600');
INSERT INTO "field_notes" VALUES(149,'1','1','138',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:52.321000','2013-09-05 22:18:52.321000');
INSERT INTO "field_notes" VALUES(150,'1','1','139',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:52.445800','2013-09-05 22:18:52.445800');
INSERT INTO "field_notes" VALUES(151,'1','1','140',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:52.757800','2013-09-05 22:18:52.757800');
INSERT INTO "field_notes" VALUES(152,'1','1','141',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:52.898200','2013-09-05 22:18:52.898200');
INSERT INTO "field_notes" VALUES(153,'1','1','142',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:52.945000','2013-09-05 22:18:52.945000');
INSERT INTO "field_notes" VALUES(154,'1','1','143',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:53.069800','2013-09-05 22:18:53.069800');
INSERT INTO "field_notes" VALUES(155,'1','1','144',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:53.147800','2013-09-05 22:18:53.147800');
INSERT INTO "field_notes" VALUES(156,'1','1','145',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:53.241400','2013-09-05 22:18:53.241400');
INSERT INTO "field_notes" VALUES(157,'1','1','146',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:53.335000','2013-09-05 22:18:53.335000');
INSERT INTO "field_notes" VALUES(158,'1','1','147',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:53.475400','2013-09-05 22:18:53.475400');
INSERT INTO "field_notes" VALUES(159,'1','1','148',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:53.584600','2013-09-05 22:18:53.584600');
INSERT INTO "field_notes" VALUES(160,'1','1','149',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:53.803000','2013-09-05 22:18:53.803000');
INSERT INTO "field_notes" VALUES(161,'1','1','150',NULL,NULL,NULL,NULL,NULL,'2013-09-05 22:18:56.252200','2013-09-05 22:18:56.252200');
DROP TABLE IF EXISTS "level_descriptors";
CREATE TABLE "level_descriptors" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "level" integer, "keystage" integer, "subject" varchar(255), "statement" varchar(255), "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);
INSERT INTO "level_descriptors" VALUES(3,16,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">Pupils begin to make connections between their own work and the work of others, and respond to these by simple communication methods.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:23:34.812600','2013-09-02 21:00:26.237400');
INSERT INTO "level_descriptors" VALUES(4,1,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They record their ideas and feelings through drawing and other methods from observation, experience and imagination.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:24:15.591000','2013-08-31 22:24:15.591000');
INSERT INTO "level_descriptors" VALUES(5,1,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They use materials and tools to make images and artefacts and experiment practically and imaginatively with the basic visual, tactile and sensory language of art, craft and design.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:24:49.817400','2013-08-31 22:24:49.817400');
INSERT INTO "level_descriptors" VALUES(6,2,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">Pupils recognise similarities and differences between their own practical work and that of others; they respond to these by simple communication methods and can describe what they feel and think about them.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:25:37.756200','2013-08-31 22:25:37.756200');
INSERT INTO "level_descriptors" VALUES(7,2,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They record their images and ideas from observation, experience, memory and imagination using a range of resources that they have collected and organised.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:26:12.481800','2013-08-31 22:26:12.481800');
INSERT INTO "level_descriptors" VALUES(8,2,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="63">
			<td height="63" style="width: 743px; height: 63px;">They use a range of materials and tools to make images and artefacts, and explore practically and imaginatively visual, tactile and sensory qualities, making changes to their work where they think these are necessary.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:26:47.940600','2013-08-31 22:26:47.940600');
INSERT INTO "level_descriptors" VALUES(9,3,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="63">
			<td height="63" style="width: 743px; height: 63px;">Pupils describe similarities and differences between their own work and that of others and begin to indicate an awareness of, and imaginative response to, the method and purposes of the work of artists, craftworkers and designers.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:27:20.591400','2013-08-31 22:27:20.591400');
INSERT INTO "level_descriptors" VALUES(10,3,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="63">
			<td height="63" style="width: 743px; height: 63px;">They select and record their ideas and feelings through drawing and other methods from observation, experience and imagination, choosing from a range of resources that they have collected and organised as a basis for their work.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:27:45.364200','2013-08-31 22:27:45.364200');
INSERT INTO "level_descriptors" VALUES(11,3,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="63">
			<td height="63" style="width: 743px; height: 63px;">They use a range of materials, tools and techniques to achieve different outcomes, and experiment with visual, tactile and sensory qualities, making suitable changes to the work where they identify the need for modification.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:28:09.793800','2013-08-31 22:28:09.793800');
INSERT INTO "level_descriptors" VALUES(12,4,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="21">
			<td height="21" style="width: 743px; height: 21px;">Pupils make comparisons between their own work and that of others from a range of cultures.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:28:46.453800','2013-08-31 22:28:46.453800');
INSERT INTO "level_descriptors" VALUES(13,4,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They communicate their ideas and feelings imaginatively, indicating an awareness of the methods used by others and demonstrating an understanding of the different purposes of their work.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:29:12.381000','2013-08-31 22:29:12.381000');
INSERT INTO "level_descriptors" VALUES(14,4,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They select and record images and ideas from observation, experience and imagination, and use a range of materials and methods to support the development of their work.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:29:38.542200','2013-08-31 22:29:38.542200');
INSERT INTO "level_descriptors" VALUES(15,4,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They prepare and develop an idea or theme for their work by collecting and organising visual and other resources.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:30:06.871800','2013-08-31 22:30:06.871800');
INSERT INTO "level_descriptors" VALUES(16,4,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="21">
			<td height="21" style="width: 743px; height: 21px;">They are able to control a range of materials, tools and techniques to achieve a variety of outcomes.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:30:32.253000','2013-08-31 22:30:32.253000');
INSERT INTO "level_descriptors" VALUES(17,4,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They apply their understanding of visual, tactile and sensory qualities and review and modify their work where they recognise the need to do so.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:30:58.336200','2013-08-31 22:30:58.336200');
INSERT INTO "level_descriptors" VALUES(18,5,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="63">
			<td height="63" style="width: 743px; height: 63px;">Pupils make comparisons between the methods and techniques used in their own work and that of others, communicating their ideas and feelings imaginatively, and clearly indicating an understanding of the methods and purposes used by others from various cultures.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:31:29.068200','2013-08-31 22:31:29.068200');
INSERT INTO "level_descriptors" VALUES(19,5,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They make drawings and use other methods selectively to explore, interpret and record their ideas and feelings from observation, experience and imagination.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:31:51.750600','2013-08-31 22:31:51.750600');
INSERT INTO "level_descriptors" VALUES(20,5,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="21">
			<td height="21" style="width: 743px; height: 21px;">They organise their work by collecting and using reference materials to develop an idea or theme.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:32:22.591800','2013-08-31 22:32:22.591800');
INSERT INTO "level_descriptors" VALUES(21,5,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="42">
			<td height="42" style="width: 743px; height: 42px;">They experiment practically and imaginatively with a variety of methods, materials, tools and techniques, applying a broad knowledge of visual, tactile and sensory qualities.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:33:40.763400','2013-08-31 22:33:40.763400');
INSERT INTO "level_descriptors" VALUES(22,5,2,'1','<table border="0" cellpadding="0" cellspacing="0" style="width: 743px;" width="742">
	<tbody>
		<tr height="21">
			<td height="21" style="width: 743px; height: 21px;">They review and modify their work to fulfil their intentions.</td>
		</tr>
	</tbody>
	<colgroup>
		<col />
	</colgroup>
</table>
','2013-08-31 22:34:09.483000','2013-08-31 22:34:09.483000');
INSERT INTO "level_descriptors" VALUES(23,7,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Children &lsquo;talk&rsquo; to themselves and can understand many more words than they can speak</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:11:45.078600','2013-09-02 19:15:59.577000');
INSERT INTO "level_descriptors" VALUES(24,7,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They repeat the names of familiar objects</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:12:52.782600','2013-09-02 19:16:21.713400');
INSERT INTO "level_descriptors" VALUES(26,7,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They follow simple instructions and begin to express themselves through role play</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:15:29.437800','2013-09-02 19:15:29.437800');
INSERT INTO "level_descriptors" VALUES(27,7,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They incerasingly want to join in songs and nursery rhymes, espeically action songs and finger rhymes</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:16:52.164600','2013-09-02 19:16:52.164600');
INSERT INTO "level_descriptors" VALUES(28,8,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Children converse simply, sometimes leaving out link words and often asking questions, e.g. &lsquo;<font class="font6">why?, and how?&rsquo;</font><font class="font5">&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:17:42.771000','2013-09-02 19:17:42.771000');
INSERT INTO "level_descriptors" VALUES(29,8,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They respond to instructions, questions and other stimuli.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:18:10.039800','2013-09-02 19:18:10.039800');
INSERT INTO "level_descriptors" VALUES(30,9,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Children draw on an increasing vocabulary in their talk.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:18:40.974600','2013-09-02 19:18:40.974600');
INSERT INTO "level_descriptors" VALUES(31,9,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They begin to use complete sentences.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:19:09.444600','2013-09-02 19:19:09.444600');
INSERT INTO "level_descriptors" VALUES(32,9,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Children listen to others and usually respond appropriately.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:20:11.002200','2013-09-02 19:20:11.002200');
INSERT INTO "level_descriptors" VALUES(33,9,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">With support they repeat/memories songs and rhymes.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:21:07.099800','2013-09-02 19:21:07.099800');
INSERT INTO "level_descriptors" VALUES(34,9,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They retell familiar stories in a simple way.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:21:38.627400','2013-09-02 19:21:38.627400');
INSERT INTO "level_descriptors" VALUES(35,13,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742"><strong>They begin to extend their ideas or accounts by including some detail.&nbsp; Children listen to others, usually responding appropriately.</strong>&nbsp;<font class="font5">Pupils talk about matters of immediate interest. They listen to others and usually respond appropriately.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:22:36.987000','2013-09-02 19:22:36.987000');
INSERT INTO "level_descriptors" VALUES(36,13,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Children speak audibly, conveying meanings to a range of listeners. </strong><font class="font5">They convey simple meanings to a range of listeners, speaking audibly, and begin to extend their ideas or accounts by providing some detail.</font><font class="font6">&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:23:10.090200','2013-09-02 19:23:10.090200');
INSERT INTO "level_descriptors" VALUES(37,14,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Children speak clearly, with increasing confidence and use a growing vocabulary.</strong><font class="font5"><strong> </strong>Pupils begin to show confidence in talking and listening, particularly where the topics interest them.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:23:41.446200','2013-09-02 19:23:41.446200');
INSERT INTO "level_descriptors" VALUES(38,14,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>They show an awareness of the needs of the listener by including relevant detail.</strong> <font class="font5">On occasions, they show awareness of the needs of the listener by including relevant detail.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:24:26.686200','2013-09-02 19:24:26.686200');
INSERT INTO "level_descriptors" VALUES(39,14,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>They understand and convey simple information.</strong>&nbsp; They usually listen carefully and respond to a wider range of stimuli.&nbsp; <font class="font5">They usually listen carefully and respond with increasing appropriateness to what others say.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:25:11.146200','2013-09-02 19:25:11.146200');
INSERT INTO "level_descriptors" VALUES(40,14,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>In some situations they adopt a more formal vocabulary and tone of voice.</strong>&nbsp; <font class="font5">They are beginning to be aware that in some situations a more formal vocabulary and tone of voice are used.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:25:50.146200','2013-09-02 19:25:50.146200');
INSERT INTO "level_descriptors" VALUES(41,14,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>They begin to realise that there is variety in the language they hear around them.</strong> <font class="font5">In developing and explaining their ideas they speak clearly and use a growing vocabulary</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:26:24.825000','2013-09-02 19:26:24.825000');
INSERT INTO "level_descriptors" VALUES(42,15,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Children begin to modify their talk to the requirements of the audience, varying the use of vocabulary and level of detail.&nbsp;</strong> <font class="font5">Pupils talk and listen confidently in different contexts, exploring and communicating ideas.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:26:59.566200','2013-09-02 19:26:59.566200');
INSERT INTO "level_descriptors" VALUES(43,15,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742"><strong>They explore and communicate ideas, showing an awareness of sequence and progression in a range of contexts.</strong>&nbsp; <font class="font5">They express an opinion simply. They are beginning to be aware of standard forms and when they are used.In discussion, they show understanding of the main points.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:27:36.273000','2013-09-02 19:27:36.273000');
INSERT INTO "level_descriptors" VALUES(44,15,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742"><strong>Through relevant comments and questions, they show that they have listened carefully.</strong>&nbsp; <font class="font5">Through relevant comments and questions they show they have listened carefully. They begin to adapt what they say to the needs of the listener, varying the use of vocabulary and the level of detail.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:28:08.346600','2013-09-02 19:28:08.346600');
INSERT INTO "level_descriptors" VALUES(45,4,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Pupils talk and listen with confidence in an increasing range of contexts.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:28:39.234600','2013-09-02 19:28:39.234600');
INSERT INTO "level_descriptors" VALUES(46,4,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Their talk is adapted to the purpose: developing and organising ideas thoughtfully, describing events and conveying their opinions clearly, including reasons occasionally.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:29:02.135400','2013-09-02 19:29:02.135400');
INSERT INTO "level_descriptors" VALUES(47,4,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">In discussion, they listen carefully, making contributions and asking questions that are responsive to others&rsquo; ideas, needs and views.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:29:27.173400','2013-09-02 19:29:27.173400');
INSERT INTO "level_descriptors" VALUES(48,4,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="width:743px;" width="742">
	<tbody>
		<tr height="19">
			<td height="19" style="height:19px;width:743px;">They can suggest changes in vocabulary and style which would improve talk. They use appropriately some of the features of standard English vocabulary and grammar.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:29:56.392200','2013-09-02 19:29:56.392200');
INSERT INTO "level_descriptors" VALUES(49,5,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Pupils talk and listen confidently in a wide range of contexts, including some that are of a formal nature.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:30:36.577800','2013-09-02 19:30:36.577800');
INSERT INTO "level_descriptors" VALUES(50,5,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Their talk engages the interest of the listener as they begin to vary their expression and vocabulary.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:31:02.848200','2013-09-02 19:31:02.848200');
INSERT INTO "level_descriptors" VALUES(51,5,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">In discussion, they pay close attention to what others say, ask questions to develop ideas and make contributions that take account of others&rsquo; views.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:31:26.731800','2013-09-02 19:31:26.731800');
INSERT INTO "level_descriptors" VALUES(52,5,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They develop their talk purposefully and when expressing opinions they provide reasons to support their views.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:31:50.490600','2013-09-02 19:31:50.490600');
INSERT INTO "level_descriptors" VALUES(53,5,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They are able to evaluate talk and understand how changes in vocabulary and style can improve its quality.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:32:26.713800','2013-09-02 19:32:26.713800');
INSERT INTO "level_descriptors" VALUES(54,5,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They begin to use standard English in formal situations.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:33:00.175800','2013-09-02 19:33:00.175800');
INSERT INTO "level_descriptors" VALUES(55,6,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Pupils adapt their talk to the demands of different contexts with growing confidence.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:33:31.797000','2013-09-02 19:33:31.797000');
INSERT INTO "level_descriptors" VALUES(56,6,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">By varying their vocabulary expression and tone, they engage the interest of the listener</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:33:55.633800','2013-09-02 19:33:55.633800');
INSERT INTO "level_descriptors" VALUES(57,6,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Pupils take an active part in discussion, using evidence to support their views</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:34:34.181400','2013-09-02 19:34:34.181400');
INSERT INTO "level_descriptors" VALUES(58,6,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They show understanding of ideas and consider how and when to respond to others.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:35:03.088200','2013-09-02 19:35:03.088200');
INSERT INTO "level_descriptors" VALUES(59,6,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They express opinions and can use evidence to support their views.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:35:43.227000','2013-09-02 19:35:43.227000');
INSERT INTO "level_descriptors" VALUES(60,6,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They are able to evaluate their own and others&rsquo; performance as speakers and can suggest ways to improve.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:36:25.269000','2013-09-02 19:36:25.269000');
INSERT INTO "level_descriptors" VALUES(61,6,NULL,'4','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They are usually fluent in their use of standard English in formal situations.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:37:01.273800','2013-09-02 19:37:01.273800');
INSERT INTO "level_descriptors" VALUES(62,7,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Children begin to follow stories read to them and they start to respond appropriately</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:49:53.083800','2013-09-02 19:49:53.083800');
INSERT INTO "level_descriptors" VALUES(63,8,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Children look at books with or without an adult and show an interest in their content.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:50:26.857800','2013-09-02 19:50:26.857800');
INSERT INTO "level_descriptors" VALUES(64,8,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They begin to follow stories from pictures and differentiate between print and pictures.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:50:57.355800','2013-09-02 19:50:57.355800');
INSERT INTO "level_descriptors" VALUES(65,9,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Children handle a book as a &lsquo;reader&rsquo; and talk about its content.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:51:33.033000','2013-09-02 19:51:33.033000');
INSERT INTO "level_descriptors" VALUES(66,9,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They begin to recognise the alphabetic nature of reading and writing and understand that written symbols have sounds and meaning.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:52:06.432600','2013-09-02 19:52:06.432600');
INSERT INTO "level_descriptors" VALUES(67,13,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="84" style="height:63.0pt">
			<td class="xl66" height="84" style="height:63.0pt;width:557pt" width="742"><strong>They recognise familiar words in simple texts and when reading aloud, use their knowledge of letters and sound-symbol relationships to read words and establish meaning</strong>. <font class="font5">Pupils recognise familiar words in simple texts. They use their knowledge of letters and sound&ndash;symbol relationships in order to read words and to establish meaning when reading aloud. In these activities they sometimes require support.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:52:55.198200','2013-09-02 19:52:55.198200');
INSERT INTO "level_descriptors" VALUES(68,13,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>They respond to poems, stories and non-fiction, sometimes needing support</strong>. <font class="font5">They express their response to poems, stories and non literary texts by identifying aspects they like.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:53:34.744200','2013-09-02 19:53:34.744200');
INSERT INTO "level_descriptors" VALUES(69,14,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Their reading of simple texts is generally accurate.<font class="font5"> Pupils&rsquo; reading of simple texts shows understanding and is generally accurate.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:54:01.872600','2013-09-02 19:54:01.872600');
INSERT INTO "level_descriptors" VALUES(70,14,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>&nbsp;They show understanding and express opinions about major events or ideas in stories, poems and non-fiction</strong>.&nbsp; <font class="font5">They express opinions about major events or ideas in stories, poems and non-literary texts.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:54:34.523400','2013-09-02 19:54:34.523400');
INSERT INTO "level_descriptors" VALUES(71,14,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742">They use a range of strategies when reading unfamiliar words and establishing meaning.&nbsp;&nbsp; Children&rsquo;s writing communicates meaning. <font class="font5">They use more than one strategy, such as phonic, graphic, syntactic and contextual, in reading unfamiliar words and establishing </font><font class="font6">meaning.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:55:21.151800','2013-09-02 19:55:21.151800');
INSERT INTO "level_descriptors" VALUES(72,15,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>They read a range of texts growing accuracy, fluency and emphasis</strong>. <font class="font5">Pupils read a range of texts fluently and accurately.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:56:00.385800','2013-09-02 19:56:00.385800');
INSERT INTO "level_descriptors" VALUES(73,15,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>They read independently, using appropriate strategies to establish meaning.</strong><font class="font5"> They can use appropriate strategies in order to read independently and establish meaning.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:56:37.716600','2013-09-02 19:56:37.716600');
INSERT INTO "level_descriptors" VALUES(74,15,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742"><strong>They respond to tests and express preferences.&nbsp; They show an understanding of the main points and talk about significant details.</strong>&nbsp; <font class="font5">In responding to literary and non-literary texts they show understanding of the main points and express preferences.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:57:16.685400','2013-09-02 19:57:16.685400');
INSERT INTO "level_descriptors" VALUES(75,15,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They use their knowledge of the alphabet to locate books and find information. <font class="font5">They use their knowledge of the alphabet to locate books and find information.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:57:51.177000','2013-09-02 19:57:51.177000');
INSERT INTO "level_descriptors" VALUES(76,4,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">In responding to a range of texts, pupils show understanding of significant ideas, themes, events and characters, and are beginning to use inference and deduction.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:58:25.497000','2013-09-02 19:58:25.497000');
INSERT INTO "level_descriptors" VALUES(77,4,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They refer to the text when explaining their views.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:58:54.045000','2013-09-02 19:58:54.045000');
INSERT INTO "level_descriptors" VALUES(78,4,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They locate and use ideas and information on a specific topic from more than one source, and use them effectively.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:59:22.686600','2013-09-02 19:59:22.686600');
INSERT INTO "level_descriptors" VALUES(79,5,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Pupils show understanding of a wide range of texts, selecting essential points and using inference and deduction where appropriate</td>
		</tr>
	</tbody>
</table>
','2013-09-02 19:59:59.830200','2013-09-02 19:59:59.830200');
INSERT INTO "level_descriptors" VALUES(80,5,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">In their responses, they identify key features, themes and characters, and select relevant words, phrases, sentences, images and other information to support their views</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:00:31.123800','2013-09-02 20:00:31.123800');
INSERT INTO "level_descriptors" VALUES(81,5,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They retrieve and collate information from a range of sources.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:01:23.711400','2013-09-02 20:01:23.711400');
INSERT INTO "level_descriptors" VALUES(82,6,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">In reading and discussing a wide range of texts, pupils select relevant words, phrases and information in order to comment on their significance and effect.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:01:49.716600','2013-09-02 20:01:49.716600');
INSERT INTO "level_descriptors" VALUES(83,6,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They are able to identify different layers of meaning in text.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:02:16.189800','2013-09-02 20:02:16.189800');
INSERT INTO "level_descriptors" VALUES(84,6,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They give personal responses to both literary and non-literary texts, referring to aspects of language, structure, themes, images and ideas in justifying their views.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:02:47.405400','2013-09-02 20:02:47.405400');
INSERT INTO "level_descriptors" VALUES(85,6,NULL,'5','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They summarise a range of information from different sources</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:03:20.134200','2013-09-02 20:03:20.134200');
INSERT INTO "level_descriptors" VALUES(86,7,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They begin to &lsquo;draw&rsquo; using their preferred hand and experiment with mark-making.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:03:53.190600','2013-09-02 20:03:53.190600');
INSERT INTO "level_descriptors" VALUES(87,8,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They try out a variety of instruments to make marks and shapes on paper or other appropriate material.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:04:22.487400','2013-09-02 20:04:22.487400');
INSERT INTO "level_descriptors" VALUES(88,9,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They hold writing instruments appropriately, discriminate between letters and begin to write in a conventional way.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:04:49.678200','2013-09-02 20:04:49.678200');
INSERT INTO "level_descriptors" VALUES(89,13,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Children&rsquo;s writing communicates meaning through simple words and phrases</strong>. <font class="font5">Pupils&rsquo; writing communicates meaning through simple words and phrases.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:05:40.159800','2013-09-02 20:05:40.159800');
INSERT INTO "level_descriptors" VALUES(90,13,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>In their reading or writing, they begin to demonstrate an understanding of how sentences work</strong>. <font class="font5">In their reading or their writing, pupils begin to show awareness of how full stops are used.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:06:22.404600','2013-09-02 20:06:22.404600');
INSERT INTO "level_descriptors" VALUES(91,13,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Children form letters, which are usually clearly shaped and correctly orientated.</strong> <font class="font5">Letters are usually clearly shaped and correctly orientated.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:06:53.682600','2013-09-02 20:06:53.682600');
INSERT INTO "level_descriptors" VALUES(92,13,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>They begin to understand the different purposes and function of written language.</strong></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:07:36.348600','2013-09-02 20:07:36.348600');
INSERT INTO "level_descriptors" VALUES(93,14,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742"><strong>They use appropriate and interesting vocabulary showing some awareness of the reader</strong>. <font class="font5">Pupils&rsquo; writing communicates meaning in both creative and factual forms, using appropriate and interesting vocabulary, and showing some awareness of form and the reader.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:08:16.737000','2013-09-02 20:08:16.737000');
INSERT INTO "level_descriptors" VALUES(94,14,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742"><strong>Ideas are often developed in a sequence of connected sentences, and capital letters and full stops are used with some degree of consistency.</strong>&nbsp; <font class="font5">Ideas are developed in a sequence of sentences, sometimes demarcated by capital letters and full stops.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:09:04.363800','2013-09-02 20:09:04.363800');
INSERT INTO "level_descriptors" VALUES(95,14,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742"><strong>Simple words are usually spelled correctly, and where there are inaccuracies, the alternative is phonically plausible.</strong> <font class="font5">Simple, monosyllabic words are usually spelled correctly, and where there are inaccuracies the alternative is phonetically plausible.&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:09:44.206200','2013-09-02 20:09:44.206200');
INSERT INTO "level_descriptors" VALUES(96,14,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>In handwriting letters are accurately formed and consistent in size</strong>.<font class="font5"> In handwriting, letters are accurately formed and consistent in size.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:10:25.998600','2013-09-02 20:10:25.998600');
INSERT INTO "level_descriptors" VALUES(97,15,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Children&rsquo;s writing is often organised, imaginative and clear</strong>.&nbsp; <font class="font5">Pupils&rsquo; writing is often organised, imaginative and clear.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:11:17.369400','2013-09-02 20:11:17.369400');
INSERT INTO "level_descriptors" VALUES(98,15,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>The main features of different forms of writing are used appropriately</strong>.<font class="font5"> The main features of different forms of writing are used appropriately, beginning to be adapted to different readers.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:11:59.115000','2013-09-02 20:11:59.115000');
INSERT INTO "level_descriptors" VALUES(99,15,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Words are chosen for variety, interest and effect.</strong>&nbsp; <font class="font5">Sequences of sentences are used to develop ideas and words are sometimes chosen for variety and interest</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:12:32.592600','2013-09-02 20:12:32.592600');
INSERT INTO "level_descriptors" VALUES(100,15,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>The basic grammatical structure of sentences is usually correct</strong>. <font class="font5">The basic grammatical structure of sentences is usually correct&nbsp;</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:13:13.105800','2013-09-02 20:13:13.105800');
INSERT INTO "level_descriptors" VALUES(101,15,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>&nbsp;Punctuation is generally accurate.</strong> <font class="font5">Punctuation to mark sentences &ndash; full stops, capital letters and question marks &ndash; is used accurately.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:13:47.067000','2013-09-02 20:13:47.067000');
INSERT INTO "level_descriptors" VALUES(102,15,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Spelling is usually accurate</strong>.&nbsp; <font class="font5">Spelling is usually accurate, including that of common, polysyllabic words.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:14:17.377800','2013-09-02 20:14:17.377800');
INSERT INTO "level_descriptors" VALUES(103,15,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742"><strong>Children produce legible writing</strong><font class="font5">&nbsp; Handwriting is legible and work is appropriately presented.</font></td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:15:00.121800','2013-09-02 20:15:00.121800');
INSERT INTO "level_descriptors" VALUES(104,4,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Pupils&rsquo; writing in a range of forms is lively. Ideas are often sustained and developed in interesting ways and organised appropriately for the purpose and reader.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:15:37.811400','2013-09-02 20:15:37.811400');
INSERT INTO "level_descriptors" VALUES(105,4,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Opinions are stated and supported with some reasons given.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:16:06.172200','2013-09-02 20:16:06.172200');
INSERT INTO "level_descriptors" VALUES(106,4,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Vocabulary choices are often adventurous and words are sometimes used for effect.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:16:35.032200','2013-09-02 20:16:35.032200');
INSERT INTO "level_descriptors" VALUES(107,4,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Pupils are beginning to extend meaning and use different sentence structures.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:17:15.342600','2013-09-02 20:17:15.342600');
INSERT INTO "level_descriptors" VALUES(108,4,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They organise their writing into paragraphs.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:17:57.899400','2013-09-02 20:17:57.899400');
INSERT INTO "level_descriptors" VALUES(109,4,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Spelling conforms to regular patterns and is generally accurate.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:18:22.672200','2013-09-02 20:18:22.672200');
INSERT INTO "level_descriptors" VALUES(110,4,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742">Full stops, capital letters and question marks are used accurately and pupils are beginning&nbsp; to use punctuation within the sentence, including inverted commas for speech.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:19:16.679400','2013-09-02 20:19:16.679400');
INSERT INTO "level_descriptors" VALUES(111,4,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="63" style="height:47.25pt">
			<td class="xl66" height="63" style="height:47.25pt;width:557pt" width="742">&nbsp;Handwriting is clear and legible and, where appropriate, presentation is adapted according to the task.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:19:43.636200','2013-09-02 20:19:43.636200');
INSERT INTO "level_descriptors" VALUES(112,5,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Pupils&rsquo; writing is varied and interesting, conveying meaning clearly in a range of forms for different readers using a more formal style where appropriate</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:20:31.528200','2013-09-02 20:20:31.528200');
INSERT INTO "level_descriptors" VALUES(113,5,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">They express opinions, supported by reasons.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:21:07.283400','2013-09-02 20:21:07.283400');
INSERT INTO "level_descriptors" VALUES(114,5,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Vocabulary choices are imaginative and words are often used precisely.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:21:43.428600','2013-09-02 20:21:43.428600');
INSERT INTO "level_descriptors" VALUES(115,5,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Simple and complex sentences are organised into paragraphs.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:22:20.509800','2013-09-02 20:22:20.509800');
INSERT INTO "level_descriptors" VALUES(116,5,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Words with complex regular patterns are usually spelled correctly.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:22:43.551000','2013-09-02 20:22:43.551000');
INSERT INTO "level_descriptors" VALUES(117,5,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">A range of punctuation is generally used accurately.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:23:17.652600','2013-09-02 20:23:17.652600');
INSERT INTO "level_descriptors" VALUES(118,5,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Work is legible and well presented.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:23:52.815000','2013-09-02 20:23:52.815000');
INSERT INTO "level_descriptors" VALUES(119,6,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Pupils&rsquo; writing often engages and sustains the reader&rsquo;s interest.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:24:35.153400','2013-09-02 20:24:35.153400');
INSERT INTO "level_descriptors" VALUES(120,6,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">&nbsp;They show some adaptation of style and register to different forms, including using an impersonal style where appropriate.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:25:06.727800','2013-09-02 20:25:06.727800');
INSERT INTO "level_descriptors" VALUES(121,6,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They present information for various purposes and express opinions, developing some points in support of a point of view.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:25:41.110200','2013-09-02 20:25:41.110200');
INSERT INTO "level_descriptors" VALUES(122,6,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">&nbsp;Pupils use a range of sentence structures and varied vocabulary to create effects.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:26:13.636200','2013-09-02 20:26:13.636200');
INSERT INTO "level_descriptors" VALUES(123,6,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">Spelling is generally accurate, including that of irregular words.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:26:56.130600','2013-09-02 20:26:56.130600');
INSERT INTO "level_descriptors" VALUES(124,6,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">&nbsp;A range of punctuation is usually used correctly to clarify meaning.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:27:20.482200','2013-09-02 20:27:20.482200');
INSERT INTO "level_descriptors" VALUES(126,6,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">&nbsp;Ideas are organised into effective paragraphs.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:29:21.039000','2013-09-02 20:29:21.039000');
INSERT INTO "level_descriptors" VALUES(127,6,NULL,'6','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="21" style="height:15.75pt">
			<td class="xl66" height="21" style="height:15.75pt;width:557pt" width="742">&nbsp;Work is legible and well presented.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:29:43.737000','2013-09-02 20:29:43.737000');
INSERT INTO "level_descriptors" VALUES(128,7,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Children anticipate, follow, respond to and join in with familiar number rhymes, stories, songs, activities and games.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:32:24.791400','2013-09-02 20:32:24.791400');
INSERT INTO "level_descriptors" VALUES(129,7,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They show an awareness of number activities, recite, sign or indicate one or more numbers to five and count or indicate two objects.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:32:58.565400','2013-09-02 20:32:58.565400');
INSERT INTO "level_descriptors" VALUES(130,7,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They are beginning to compare physical properties of objects.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:33:24.383400','2013-09-02 20:33:24.383400');
INSERT INTO "level_descriptors" VALUES(131,7,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They demonstrate interest in position and the relationship between objects.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:33:50.747400','2013-09-02 20:33:50.747400');
INSERT INTO "level_descriptors" VALUES(132,7,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They sort and match objects or pictures by recognising similarities.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:34:20.106600','2013-09-02 20:34:20.106600');
INSERT INTO "level_descriptors" VALUES(133,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Children use mathematics in day-to-day activities and in their play, responding appropriately to key vocabulary and questions.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:34:55.721400','2013-09-02 20:34:55.721400');
INSERT INTO "level_descriptors" VALUES(134,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They join in rote counting of numbers from 1-10.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:35:25.252200','2013-09-02 20:35:25.252200');
INSERT INTO "level_descriptors" VALUES(135,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They recognise and name numbers 1 to 3, and count up to three objects reliably.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:35:49.073400','2013-09-02 20:35:49.073400');
INSERT INTO "level_descriptors" VALUES(136,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They record numbers initially by making marks or drawing pictures.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:36:20.741400','2013-09-02 20:36:20.741400');
INSERT INTO "level_descriptors" VALUES(137,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They begin to develop an understanding of one-to-one correspondence by matching pairs of different objects or pictures.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:36:45.561000','2013-09-02 20:36:45.561000');
INSERT INTO "level_descriptors" VALUES(138,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They understand the concept of &lsquo;one more&rsquo;.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:37:17.853000','2013-09-02 20:37:17.853000');
INSERT INTO "level_descriptors" VALUES(139,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">In their play, they develop an awareness of the purpose of money.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:37:46.307400','2013-09-02 20:37:46.307400');
INSERT INTO "level_descriptors" VALUES(140,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They show understanding of words, signs and symbols that describe size and positions.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:38:13.061400','2013-09-02 20:38:13.061400');
INSERT INTO "level_descriptors" VALUES(141,8,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">&nbsp;They sort objects using one criterion, and are aware of contrasting qualities.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:38:40.501800','2013-09-02 20:38:40.501800');
INSERT INTO "level_descriptors" VALUES(142,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">Children use familiar words in practical situations.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:39:21.561000','2013-09-02 20:39:21.561000');
INSERT INTO "level_descriptors" VALUES(143,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They rote count to beyond 10, and onwards from a given small number.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:39:52.090200','2013-09-02 20:39:52.090200');
INSERT INTO "level_descriptors" VALUES(144,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They carry out simple addition using numbers 1 to 5 and understand that zero means none.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:40:18.235800','2013-09-02 20:40:18.235800');
INSERT INTO "level_descriptors" VALUES(145,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">
			<p>They recognise and try to record numerals from one to nine.</p>
			</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:40:59.139000','2013-09-02 20:40:59.139000');
INSERT INTO "level_descriptors" VALUES(146,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">&nbsp;They understand the concept of &lsquo;one less&rsquo;.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:41:31.399800','2013-09-02 20:41:31.399800');
INSERT INTO "level_descriptors" VALUES(147,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They compare and order two or more objects by direct observation.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:41:56.328600','2013-09-02 20:41:56.328600');
INSERT INTO "level_descriptors" VALUES(148,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They show awareness of time in terms of their daily activities.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:42:23.191800','2013-09-02 20:42:23.191800');
INSERT INTO "level_descriptors" VALUES(149,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">They talk about or indicate, recognise and copy simple repeating patterns and sequences.&nbsp;</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:42:53.877000','2013-09-02 20:42:53.877000');
INSERT INTO "level_descriptors" VALUES(150,9,NULL,'11','<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:
 collapse;width:557pt" width="742">
	<tbody>
		<tr height="42" style="height:31.5pt">
			<td class="xl66" height="42" style="height:31.5pt;width:557pt" width="742">When sorting, they recognise when an object is different and does not belong to a familiar category.</td>
		</tr>
	</tbody>
</table>
','2013-09-02 20:43:23.501400','2013-09-02 20:43:23.501400');
DROP TABLE IF EXISTS "levels";
CREATE TABLE "levels" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar(255), "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);
INSERT INTO "levels" VALUES(7,'Outcome 1','2013-08-31 20:45:54.220200','2013-08-31 20:45:54.220200');
INSERT INTO "levels" VALUES(8,'Outcome 2','2013-08-31 20:46:03.751800','2013-08-31 20:46:23.907000');
INSERT INTO "levels" VALUES(9,'Outcome 3','2013-08-31 20:46:11.723400','2013-08-31 20:46:34.951800');
INSERT INTO "levels" VALUES(10,'Outcome 4','2013-08-31 20:46:45.123000','2013-08-31 20:46:45.123000');
INSERT INTO "levels" VALUES(11,'Outcome 5','2013-08-31 20:46:57.415800','2013-08-31 20:46:57.415800');
INSERT INTO "levels" VALUES(12,'Outcome 6','2013-08-31 20:47:10.410600','2013-08-31 20:47:10.410600');
INSERT INTO "levels" VALUES(13,'Outcome 4/Level 1','2013-08-31 20:47:48.755400','2013-08-31 20:47:48.755400');
INSERT INTO "levels" VALUES(14,'Outcome 5/Level 2','2013-08-31 20:48:09.909000','2013-08-31 20:48:09.909000');
INSERT INTO "levels" VALUES(15,'Outcome 6/Level 3','2013-08-31 20:48:29.253000','2013-08-31 20:48:29.253000');
INSERT INTO "levels" VALUES(16,'Level 1','2013-09-02 20:56:58.710600','2013-09-02 20:56:58.710600');
INSERT INTO "levels" VALUES(17,'Level 2','2013-09-02 20:57:10.239000','2013-09-02 20:57:10.239000');
INSERT INTO "levels" VALUES(18,'Level 3','2013-09-02 20:57:22.672200','2013-09-02 20:57:22.672200');
INSERT INTO "levels" VALUES(19,'Level 4','2013-09-02 20:57:33.561000','2013-09-02 20:57:33.561000');
INSERT INTO "levels" VALUES(20,'Level 5','2013-09-02 20:58:14.667000','2013-09-02 20:58:14.667000');
INSERT INTO "levels" VALUES(21,'Level 6','2013-09-02 20:58:27.583800','2013-09-02 20:58:27.583800');
DROP TABLE IF EXISTS "messages";
CREATE TABLE "messages" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "subject" varchar(255), "to" varchar(255), "cc" varchar(255), "from" varchar(255), "bcc" varchar(255), "body" text, "created_at" datetime NOT NULL, "deleted_at" datetime, "read_at" datetime, "deleted" varchar(255), "updated_at" datetime NOT NULL);
DROP TABLE IF EXISTS "pupils";
CREATE TABLE "pupils" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "forname" varchar(255), "surname" varchar(255), "gender" varchar(255), "dob" date, "class_id" varchar(255), "registration_group" varchar(255), "FSM" boolean, "MAT" varchar(255), "SEN" varchar(255), "EAL" varchar(255), "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);
INSERT INTO "pupils" VALUES(1,'test','test','female','2012-02-12','','1','t','','','','2013-08-03 21:45:51.198203','2013-08-03 21:45:51.198203');
DROP TABLE IF EXISTS "registration_groups";
CREATE TABLE "registration_groups" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "registrationgroup" varchar(255), "teacher" varchar(255), "graduation_year" varchar(255), "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);
INSERT INTO "registration_groups" VALUES(1,'zzz','',' 2015','2013-08-03 21:45:05.075565','2013-08-03 21:45:05.075565');
DROP TABLE IF EXISTS "schema_migrations";
CREATE TABLE "schema_migrations" ("version" varchar(255) NOT NULL);
INSERT INTO "schema_migrations" VALUES('20130207222920');
INSERT INTO "schema_migrations" VALUES('20130210201157');
INSERT INTO "schema_migrations" VALUES('20130223212711');
INSERT INTO "schema_migrations" VALUES('20130518200423');
INSERT INTO "schema_migrations" VALUES('20130526093629');
INSERT INTO "schema_migrations" VALUES('20130529220845');
INSERT INTO "schema_migrations" VALUES('20130529222531');
INSERT INTO "schema_migrations" VALUES('20130530223639');
INSERT INTO "schema_migrations" VALUES('20130611194334');
DROP TABLE IF EXISTS "subjects";
CREATE TABLE "subjects" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "subject_name" varchar(255), "subject_type" varchar(255), "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);
INSERT INTO "subjects" VALUES(1,'Art and Design','Foundation','2013-08-03 21:46:21.500937','2013-08-31 20:13:27.777000');
INSERT INTO "subjects" VALUES(2,'Creative Development','Foundation','2013-08-31 20:14:18.289800','2013-08-31 20:14:18.289800');
INSERT INTO "subjects" VALUES(3,'Design and Technology','Foundation','2013-08-31 20:14:54.169800','2013-08-31 20:14:54.169800');
INSERT INTO "subjects" VALUES(4,'English/LLC-Oracy','Core','2013-08-31 20:15:31.999800','2013-08-31 20:15:31.999800');
INSERT INTO "subjects" VALUES(5,'English/LLC-Reading','Core','2013-08-31 20:16:05.758200','2013-08-31 20:16:05.758200');
INSERT INTO "subjects" VALUES(6,'English/LLC-Writing','Core','2013-08-31 20:16:30.063000','2013-08-31 20:16:30.063000');
INSERT INTO "subjects" VALUES(7,'Geography','Foundation','2013-08-31 20:16:56.083800','2013-08-31 20:16:56.083800');
INSERT INTO "subjects" VALUES(8,'History','Foundation','2013-08-31 20:17:20.794200','2013-08-31 20:17:20.794200');
INSERT INTO "subjects" VALUES(9,'Information Technology','Foundation','2013-08-31 20:17:44.677800','2013-08-31 20:17:44.677800');
INSERT INTO "subjects" VALUES(10,'Knowledge and Understanding of the World','Foundation','2013-08-31 20:18:13.428600','2013-08-31 20:18:13.428600');
INSERT INTO "subjects" VALUES(11,'Maths/Mathematical Development','Core','2013-08-31 20:18:53.567400','2013-08-31 20:18:53.567400');
INSERT INTO "subjects" VALUES(12,'Music','Foundation','2013-08-31 20:19:27.700200','2013-08-31 20:19:27.700200');
INSERT INTO "subjects" VALUES(13,'Physical Development','Foundation','2013-08-31 20:19:59.025000','2013-08-31 20:19:59.025000');
INSERT INTO "subjects" VALUES(14,'Physical Education','Foundation','2013-08-31 20:20:31.410600','2013-08-31 20:20:31.410600');
INSERT INTO "subjects" VALUES(15,'PSD,WB & CD','Core','2013-08-31 20:21:03.749400','2013-08-31 20:21:03.749400');
INSERT INTO "subjects" VALUES(16,'Religious Education','Core','2013-08-31 20:21:38.880600','2013-08-31 20:21:38.880600');
INSERT INTO "subjects" VALUES(17,'Science','Core','2013-08-31 20:21:55.853400','2013-08-31 20:21:55.853400');
INSERT INTO "subjects" VALUES(18,'Welsh-Oracy','Core','2013-08-31 20:22:22.467000','2013-08-31 20:22:22.467000');
INSERT INTO "subjects" VALUES(19,'Welsh-Reading','Core','2013-08-31 20:23:03.354600','2013-08-31 20:23:03.354600');
INSERT INTO "subjects" VALUES(20,'Welsh-Writing','Core','2013-08-31 20:23:33.587400','2013-08-31 20:23:33.587400');
DROP TABLE IF EXISTS "user_sessions";
CREATE TABLE "user_sessions" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "session_id" varchar(255) NOT NULL, "data" text, "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);
DROP TABLE IF EXISTS "users";
CREATE TABLE "users" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar(255) DEFAULT '' NOT NULL, "login" varchar(255), "crypted_password" varchar(255) NOT NULL, "password_salt" varchar(255) NOT NULL, "email" varchar(255) NOT NULL, "registration_code" varchar(255) NOT NULL, "persistence_token" varchar(255) NOT NULL, "single_access_token" varchar(255) NOT NULL, "perishable_token" varchar(255) NOT NULL, "login_count" integer DEFAULT 0 NOT NULL, "failed_login_count" integer DEFAULT 0 NOT NULL, "last_request_at" datetime, "current_login_at" datetime, "last_login_at" datetime, "current_login_ip" varchar(255), "last_login_ip" varchar(255), "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL, "roles" varchar(255) DEFAULT '--- []');
INSERT INTO "users" VALUES(1,'test',NULL,'3c7a626e54f3a670bf2c24617bf2dd249cf5e2bc8f7647147a670200ebb7d64cd77f3b25ebbe09a3faceef18a7070ec9ed52c699e31c82b950bf0d5269fb913b','DOgGiTfVA3011L1fO','tester@test.com','school','e41778769c3e562d15d21854e280470f3d0ddf419e2da7131537b3f54df57621926db4330a1810d2e4e79e21653fc9abce79eeae6d3c2c2035406e11450d1549','OYLA7NPgz04b4nunBkqN','9DaWBpvJOijHAQeGHej0',77,0,'2013-09-05 22:30:44.773000','2013-09-05 22:30:28.705000','2013-09-05 22:18:31.151800','81.130.69.206','81.130.69.206','2013-08-03 21:42:06.827370','2013-09-05 22:30:44.773000','---
- user
- admin
');
INSERT INTO "users" VALUES(2,'Louise Muteham',NULL,'b1a48908f56c9597184e89511987ac031dceeefc9aaf711d0ded6dbec57f3ee662a021edc7b3997b4106a578f596cbc9110b16f24ca2e3efa0ed1fd0630ef7bc','O9CytAqhOoq8XnWPAFtt','lmuteham@hotmail.co.uk','school','b3d5866f46f7e526469d8dc9347f5ac3b22310c08c8f1c6ae9f243d2c9d11f8e39fb4228d6aa73b4c3d423c7d403d9b1f2d96deda868d952513aea1fd61c2325','3hSbwQXCEGvxt4VfLDGC','f4duHAmWjSiAter7B2ZV',11,0,'2013-09-02 21:23:31.891800','2013-09-02 21:23:16.120200','2013-09-02 21:17:29.878200','81.130.69.206','81.130.69.206','2013-08-31 20:39:59.647800','2013-09-02 21:23:31.891800','---
- user
- admin
');
CREATE INDEX "index_user_sessions_on_session_id" ON "user_sessions" ("session_id");
CREATE INDEX "index_user_sessions_on_updated_at" ON "user_sessions" ("updated_at");
CREATE UNIQUE INDEX "unique_schema_migrations" ON "schema_migrations" ("version");
