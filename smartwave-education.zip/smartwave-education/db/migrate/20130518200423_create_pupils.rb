class CreatePupils < ActiveRecord::Migration
  def change
    create_table :pupils do |t|
      t.string :forname
      t.string :surname
      t.string :gender
      t.date :dob
      t.string :class_id
      t.string :registration_group
      t.boolean :fsm
      t.string :mat
      t.string :sen
      t.string :eal

      t.timestamps
    end
  end
end
