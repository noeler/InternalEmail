class CreateLevelDescriptors < ActiveRecord::Migration
  def change
    create_table :level_descriptors do |t|
      t.integer :level
      t.integer :keystage
      t.string :subject
      t.string :statement

      t.timestamps
    end
  end
end
