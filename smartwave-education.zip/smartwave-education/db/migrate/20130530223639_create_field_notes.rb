class CreateFieldNotes < ActiveRecord::Migration
  def change
    create_table :field_notes do |t|
      t.string :pupil
      t.string :subject
      t.string :level_descriptor
      t.string :statement
      t.string :red
      t.string :yellow
      t.string :green
      t.string :comment

      t.timestamps
    end
  end
end
