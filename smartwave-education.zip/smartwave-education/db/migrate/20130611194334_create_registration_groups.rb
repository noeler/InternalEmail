class CreateRegistrationGroups < ActiveRecord::Migration
  def change
    create_table :registration_groups do |t|
      t.string :registrationgroup
      t.string :teacher
      t.string :graduation_year

      t.timestamps
    end
  end
end
