Innotrack::Application.routes.draw do
  get "errors/error_404"

  get "errors/error_500"

  resources :registration_groups do
    collection do
      get 'search'
    end
  end
  
  resources :help do
    collection do
      get 'about'
      get 'releases'
    end
  end
  
  resources :welcome
  
  resources :field_notes do
    collection do
      get 'index2'
      get 'single_pupil'
      post 'save_single_pupil'
      get 'load_value'
      post 'save_value'
      get 'load_comment'
      post 'save_comment'
      get 'create_pdf'
    end
  end

  resources :levels

  resources :uploads
  
  resources :subjects do
    collection do
      get 'search'
    end
  end
  

  resources :level_descriptors do
    collection do
      get 'import'
      get 'download'
      post 'upload'
      get 'delete_all'
      post 'import_file'
    end
  end

  resources :pupils do
    collection do
      get 'search'
      get 'search_reggroup'
      get 'import'
      get 'download'
      get 'delete_all'
      post 'import_file'
    end
  end

  resources :qrcode do
    collection do
      get 'qrcode'
    end
  end
  
  #get "welcome/index"

  resources :messages
  resources :user_sessions
    
  resources :users do
    member do
      get 'add_admin'
      get 'remove_admin'
    end
  end
  match 'home' => "welcome#index", :as => :home
  match 'login' => "user_sessions#new",      :as => :login
  match 'logout' => "user_sessions#destroy", :as => :logout
  match 'timeout' => "user_sessions#timeout", :as => :timeout

  match 'compose' => "messages#new", :as => :compose
  match 'inbox' => "messages#index", :as => :inbox
  match 'sent' => "messages#sent", :as => :sent
  match 'deleted' => "messages#deleted", :as => :deleted
  match 'messages/:id/reply' => "messages#reply", :as => :reply
  match 'messages/:id/forward' => "messages#forward", :as => :forward
  match 'messages/:id/create_forward' => "messages#create_forward", :as => :create_forward
  match 'messages/:id/move_inbox' => "messages#move_inbox", :as => :move_inbox
  match 'empty_deleted' => "messages#empty_deleted", :as => :empty_deleted

  match 'myprofile' => "users#myprofile", :as => :myprofile
  
  #match 'pupils/import' => "pupils#import", :as => :import
  #match 'pupils/download' => "pupils#download", :as => :download
  
  #resource :user, :as => 'account'  # a convenience route

  match 'signup' => 'users#new', :as => :signup
   
  root :to => 'users#new'
  # The priority is based upon order of creation:
  # first created -> highest priority.

  # Sample of regular route:
  #   match 'products/:id' => 'catalog#view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   match 'products/:id/purchase' => 'catalog#purchase', :as => :purchase
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Sample resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Sample resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Sample resource route with more complex sub-resources
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', :on => :collection
  #     end
  #   end

  # Sample resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end

  # You can have the root of your site routed with "root"
  # just remember to delete public/index.html.
  # root :to => 'welcome#index'

  # See how all your routes lay out with "rake routes"

  # This is a legacy wild controller route that's not recommended for RESTful applications.
  # Note: This route will make all actions in every controller accessible via GET requests.
  # match ':controller(/:action(/:id))(.:format)'
  #unless Rails.application.config.consider_all_requests_local
    match '*not_found', to: 'errors#error_404'
  #end

end
