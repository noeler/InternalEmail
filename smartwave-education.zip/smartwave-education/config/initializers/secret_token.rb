# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Innotrack::Application.config.secret_token = 'ec8c5d310a2178822857fec3df82450c563b7f6dd7f6eb76beedb393c607ad0da2503f02612ea3eb0729107e204d188b3736e58b6183159aa83a8767cdb77122'
