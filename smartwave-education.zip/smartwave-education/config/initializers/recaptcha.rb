Recaptcha.configure do |config|
  config.public_key  = '6LcH8NwSAAAAANv5JdioQCvyt5Qym1wGApk9MTVc'
  config.private_key = '6LcH8NwSAAAAAL1Viksv9Ye8-Bb4-Wwg71v-eZRL'
end