class FieldNotesController < ApplicationController
  before_filter :require_user
  require 'date'
  require 'json'
  require 'prawn'
 
  # GET /field_notes
  # GET /field_notes.json
  def index
    @field_notes = FieldNote.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @field_notes }
    end
  end

  def index2
    @field_notes = FieldNote.all

    respond_to do |format|
      format.html {render action: "index2"}# index.html.erb
      format.json { render json: @field_notes }
    end
  end


  # GET /field_notes/1
  # GET /field_notes/1.json
  def show
    @field_note = FieldNote.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @field_note }
    end
  end

  # GET /field_notes/new
  # GET /field_notes/new.json
  def new
    @field_note = FieldNote.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @field_note }
    end
  end

  # GET /field_notes/1/edit
  def edit
    @field_note = FieldNote.find(params[:id])
  end

  # POST /field_notes
  # POST /field_notes.json
  def create
    @field_note = FieldNote.new(params[:field_note])

    respond_to do |format|
      if @field_note.save
        format.html { redirect_to @field_note, notice: 'Field note was successfully created.' }
        format.json { render json: @field_note, status: :created, location: @field_note }
      else
        format.html { render action: "new" }
        format.json { render json: @field_note.errors, status: :unprocessable_entity }
      end
    end
  end

  # PUT /field_notes/1
  # PUT /field_notes/1.json
  def update
    @field_note = FieldNote.find(params[:id])

    respond_to do |format|
      if @field_note.update_attributes(params[:field_note])
        format.html { redirect_to @field_note, notice: 'Field note was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @field_note.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /field_notes/1
  # DELETE /field_notes/1.json
  def destroy
    @field_note = FieldNote.find(params[:id])
    @field_note.destroy

    respond_to do |format|
      format.html { redirect_to field_notes_url }
      format.json { head :no_content }
    end
  end
  
  # GET /field_notes/single_pupil
  def single_pupil
    @field_note = FieldNote.new
    @pupil = Pupil.find(params[:pupil])
    #@field_notes = FieldNote.where(:pupil => @pupil.id)
    #@messages = Message.where(:to => current_user.email ,:deleted => "true")
    @levels = Level.all

    @levels2 = Array.new
    @levels.each do |level|
      #check the number of level descripts for a specific level
      @LDCounter = LevelDescriptor.where(level: level, subject: params[:subject]).count
      puts @LDCounter.to_s
      if @LDCounter.to_i > 0 
        puts "Has level descriptors " + level.to_s
        @levels2.push(level)
      end
    end


    #query = ["%#{params[:subject]}%"]
    #sql = "subject = '?'" 
    #@pupils = Pupil.where([sql, *query])

    #@level_descriptors = LevelDescriptor.where([sql, *query])
    
    @level_descriptors = LevelDescriptor.where(subject: params[:subject])
    @subject=Subject.find(params[:subject])

    
    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @field_notes }
    end
  end
  
  def save_single_pupil
       puts params[:field_note]
       @field_note = FieldNote.new(params[:field_note])
       puts @field_note
    respond_to do |format|
      if @field_note.save
        format.html { redirect_to @field_note, notice: 'Field note was successfully created.' }
        format.json { render json: @field_note, status: :created, location: @field_note }
      else
        format.html { render action: "new" }
        format.json { render json: @field_note.errors, status: :unprocessable_entity }
      end
    end
  end

  def save_value
    @field_note = FieldNote.where("pupil = ? AND level_descriptor = ? AND subject = ?", params[:pupil], params[:level_descriptor], params[:subject]) || FieldNote.new(params[:field_note])
    if @field_note
      #puts @field_note.comment
      
      if (params[:red].present?)
        @field_note.update_all(:red => params[:red])
      end
      if (params[:yellow].present?)
        @field_note.update_all(:yellow => params[:yellow])
      end
      if (params[:green].present?)
        @field_note.update_all(:green => params[:green])
      end
      #,:yellow => params[:yellow],:green => params[:green])
    end
    respond_to do |format|
      format.html { redirect_to field_notes_url }
      format.json { head :no_content }
    end
  end
  
  def load_value
    @field_note = FieldNote.where(pupil: params[:pupil], level_descriptor: params[:level_descriptor], subject: params[:subject]).first || FieldNote.create(:pupil => params[:pupil], :level_descriptor => params[:level_descriptor], :subject => params[:subject])    

    respond_to do |format|
      #format.html {redirect_to field_notes_url }
      format.json { render json: @field_note }
    end
  end
  
  def save_comment
    puts "In save comment"

    @field_note = FieldNote.where(pupil: params[:pupil], level_descriptor: params[:level_descriptor], subject: params[:subject]).first #|| FieldNote.create(:pupil => params[:pupil], :level_descriptor => params[:level_descriptor], :subject => params[:subject])    

    #@field_note = FieldNote.where("pupil = ? AND level_descriptor = ? AND subject = ?", params[:pupil], params[:level_descriptor], params[:subject]) || FieldNote.new(params[:field_note])
    if @field_note
      puts params[:comment]
      level = params[:level_descriptor]
      @field_note.update_attributes(:comment => params[:comment] + "\r" + DateTime.now.to_s + " " + current_user.name + "\r")
      #@field_note.save
    end
    
    respond_to do |format|
     # format.html {redirect_to field_notes_url }
      format.json { head :no_content }
    end
  end  
  
  def load_comment  
    @field_note = FieldNote.where(pupil: params[:pupil], level_descriptor: params[:level_descriptor], subject: params[:subject])    
    respond_to do |format|
      format.json { render json: @field_note }
    end
  end
  
  def create_pdf
    output = PDFDocument.new.to_pdf
    respond_to do |format|
      format.pdf {send_data output, filename: "hello.pdf", type: "application/pdf", disposition: "inline"}
      format.html {render text: "<h1>Use .pdf</h1>".html_safe}
    end
  end
  
  class PDFDocument < Prawn::Document
      def to_pdf
        t = make_table([ ["this is the first row"],
                         ["this is the second row"] ])
        t.draw
        render
      end
    end
  
end
