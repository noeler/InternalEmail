class PupilsController < ApplicationController
   before_filter :require_user
   include CsvMapper

   
 # GET /pupils
  # GET /pupils.json
  def index
    @pupils = Pupil.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @pupils }
    end
  end

  # GET /pupils/search
  # GET /pupils/search.json
  def search
    puts params[:q]
    
    query = ["%#{params[:q]}%","%#{params[:q]}%"]
    sql = "forname LIKE ? OR surname LIKE ?" 
    @pupils = Pupil.where([sql, *query])
    
    #@pupils = Pupil.where("forname LIKE ?", params[:q]) 

    respond_to do |format|
      #format.html # index.html.erb
      format.json { render json: @pupils }
    end
  end

  # GET /pupils/search_reggroup
  # GET /pupils/search_reggroup.json
  def search_reggroup
    puts params[:q]
    puts params[:reggroup]
    query = ["#{params[:reggroup]}","%#{params[:q]}%","%#{params[:q]}%"]
    sql = "registration_group= ? AND (forname LIKE ? OR surname LIKE ?)" 
    @pupils = Pupil.where([sql, *query])
    
    #@pupils = Pupil.where("forname LIKE ?", params[:q]) 

    respond_to do |format|
      #format.html # index.html.erb
      format.json { render json: @pupils }
    end
  end
  
  # GET /pupils/1
  # GET /pupils/1.json
  def show
    @pupil = Pupil.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @pupil }
    end
  end

  # GET /pupils/new
  # GET /pupils/new.json
  def new
    @pupil = Pupil.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @pupil }
    end
  end

  # GET /pupils/1/edit
  def edit
    @pupil = Pupil.find(params[:id])
  end

  # POST /pupils
  # POST /pupils.json
  def create
    @pupil = Pupil.new(params[:pupil])

    respond_to do |format|
      if @pupil.save
        format.html { redirect_to @pupil, notice: 'Pupil was successfully created.' }
        format.json { render json: @pupil, status: :created, location: @pupil }
      else
        format.html { render action: "new" }
        format.json { render json: @pupil.errors, status: :unprocessable_entity }
      end
    end
  end


  # PUT /pupils/1
  # PUT /pupils/1.json
  def update
    @pupil = Pupil.find(params[:id])

    respond_to do |format|
      if @pupil.update_attributes(params[:pupil])
        format.html { redirect_to @pupil, notice: 'Pupil was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @pupil.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /pupils/1
  # DELETE /pupils/1.json
  def destroy
    @pupil = Pupil.find(params[:id])
    @pupil.destroy

    respond_to do |format|
      format.html { redirect_to pupils_url }
      format.json { head :no_content }
    end
  end
  
    def delete_all
    Pupil.delete_all
    
    respond_to do |format|
      format.html { redirect_to pupils_url, notice: 'All Pupils deleted' }
      format.json { head :no_content }
    end
  end
  
  def import
    @files = Dir.entries("public/uploads")

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @pupil }
    end
  end
  
   def import_file
    results = CsvMapper.import('public/uploads/' + params[:datafile]) do
      map_to Pupil # Map to the Person ActiveRecord class (defined above) instead of the default OpenStruct.
      after_row lambda{|row, pupil| pupil.save }  # Call this lambda and save each record after it's parsed.#

      start_at_row 1
      [forname,surname,gender,dob,class_id,registration_group,fsm,mat,sen,eal]
    end
    
    respond_to do |format|
      format.html { redirect_to pupils_url, notice: 'Pupils imported successfully.' }
    end
    
  end
  
end