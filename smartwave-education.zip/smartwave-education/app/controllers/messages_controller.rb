class MessagesController < ApplicationController
  before_filter :require_user
  
 

  # GET /messages
  # GET /messages.json
  def index 
    @messages = Message.where(:to => current_user.email ,:deleted => nil)
    
    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @messages }
    end
  end

  def sent
    @messages = Message.where(:from => current_user.email ,:deleted => nil)
    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @messages }
    end 
  end

  def deleted
    #server.names.find(:all, :conditions => [name LIKE  ? AND name LIKE ?", "%wer%", "%asd%"])
    @messages = Message.where(:to => current_user.email ,:deleted => "true")
    

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @messages }
    end 
  end


  # GET /messages/1
  # GET /messages/1.json
  def show
    @message = Message.find(params[:id])
    @message.update_attributes(:read_at => DateTime.now)
    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @message }
    end
  end

  # GET /messages/new
  # GET /messages/new.json
  def new
    @message = Message.new
    @users = User.find(:all)
    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @message }
    end
  end

  # GET /messages/1/edit
  def edit
    @message = Message.find(params[:id])
  end

  # POST /messages
  # POST /messages.json
  def create
    @message = Message.new(params[:message])
    @message.from = current_user.email
    
    @users = User.find(:all)

    respond_to do |format|
      if @message.save
        #format.html { redirect_to @messages, notice: 'Message was successfully created.' }
        @messages = Message.where(:to => current_user.email ,:deleted => nil)

        format.html { render action: "index", notice: 'Message was successfully created.' }
        format.json { render json: @message, status: :created, location: @message }
      else
        format.html { render action: "new" }
        format.json { render json: @message.errors, status: :unprocessable_entity }
      end
    end
  end

  # PUT /messages/1
  # PUT /messages/1.json
  def update
    @message = Message.find(params[:id])

    respond_to do |format|
      if @message.update_attributes(params[:message])
        format.html { redirect_to @message, notice: 'Message was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @message.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /messages/1
  # DELETE /messages/1.json
  def destroy
    @message = Message.find(params[:id])

    respond_to do |format|   
      
      if @message.update_attributes(:deleted => "true")
        
        @messages = Message.where(:to => current_user.email ,:deleted => "")

        format.html { redirect_to :inbox, notice: 'Message was successfully moved to deleted items.' }
        format.json { head :no_content }
      else
        format.html { redirect_to :inbox}
        format.json { render json: @message.errors, status: :unprocessable_entity }
      end
    end
  end
  
  def delete_perm
    @message = Message.find(params[:id])
    @message.destroy

    respond_to do |format|
      format.html { render action: "index", notice: 'Message deleted.' }
      format.json { head :no_content }
    end
  end
  
  def empty_deleted
    @messages = Message.where(:to => current_user.email ,:deleted => "true")

   
    @messages.delete_all("deleted='true'")
    
    respond_to do |format|
      format.html { redirect_to :deleted, notice: 'Deleted messages emptied.' }
      format.json { head :no_content }
    end
  end
  
  def move_inbox
    @message = Message.find(params[:id])
    
    respond_to do |format|   
      
      if @message.update_attributes(:deleted => nil)
        
        @messages = Message.where(:to => current_user.email ,:deleted => "true")

        format.html { redirect_to :deleted, notice: 'Message was successfully moved to inbox.' }
        format.json { head :no_content }
      else
        format.html { render action: "index" }
        format.json { render json: @message.errors, status: :unprocessable_entity }
      end
    end
  end
  
  def reply
    @message = Message.find(params[:id])
    puts @message
    @reply = Message.new(params[:message])

    @reply.to = @message.from
    puts @reply.to
    
    @reply.from = current_user.email
    @reply.subject = "RE: " + @message.subject
    @reply.body = "-----------------------------------\n\nFrom:"+ @message.body

    @users = User.find(:all)

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @message }
    end
  end
  
  def create_reply 
    respond_to do |format|
      if @reply.save
        p @reply
        #format.html { redirect_to @messages, notice: 'Message was successfully created.' }
        @messages = Message.where(:to => current_user.email ,:deleted => nil)
        
        format.html { render action: "index", notice: 'Reply was successfully sent' }
        format.json { render json: @message, status: :created, location: @message }
      else
       format.html { render action: "new" }
       format.json { render json: @message.errors, status: :unprocessable_entity }
      end
    end
  end

 def forward
    @message = Message.find(params[:id])
    @forward = Message.new(params[:message])
   
    @forward.to = ""
    @forward.from = current_user.email
    @forward.subject = "FW: " + @message.subject
    @forward.body = "-----------------------------------\n\nFrom:"+ @message.body

    @users = User.find(:all)
   
    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @message }
    end
 end 
  
  def create_forward
    @emailaddresses = User.select(:email)
    @forward = Message.new(params[:message])
    @forward.from = current_user.email
    respond_to do |format|
      if @forward.save
        #format.html { redirect_to @messages, notice: 'Message was successfully created.' }
        @messages = Message.where(:to => current_user.email ,:deleted => nil)

        format.html { render action: "index", notice: 'Message forwarded successfully' }
        format.json { render json: @message, status: :created, location: @message }
      else
        format.html { render action: "forward" }
        format.json { render json: @message.errors, status: :unprocessable_entity }
      end
    end
  end

end
