class UserSessionsController < ApplicationController 
 # before_filter :require_user, :only => [:new, :create, :destroy]

  def new
    @user_session = UserSession.new
  end

  def create
    @user_session = UserSession.new(params[:user_session])
    if @user_session.save
      flash[:notice] = "Login successful!"
      #redirect_to root_url
      redirect_back_or_default :home
    else
      render :action => :new
    end
  end

  def destroy
    current_user_session.destroy
    flash[:notice] = "Logout successful!"
    redirect_to root_url
  end
  
def timeout
    #if Rails.env.development?
    #  logout = false
    #else
      logout = current_user_session.stale?
    #end
 
    respond_to do |format|
      format.json { render :json => logout}
    end
  end
 
  # Authlogic attempts to call this method within your 
  # controller, you can define whatever you'd like in here to 
  # not track the last_request_at. We need to disable the
  # update of last_request_at for our ajax timeout action 'timeout' 
  # since we would basically be overwriting ourselves. You can
  # put whatever functionality you need in here, it just needs
  # to return true/false.
  def last_request_update_allowed?
    action_name != "timeout"
  end
  
  
end