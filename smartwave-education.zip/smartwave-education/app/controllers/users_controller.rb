class UsersController < ApplicationController  
  #before_filter :require_admin, :only => [:index, :show, :edit, :update, :add_admin, :remove_admin]
  #before_filter :require_user #, :only => [:myprofile]
  
  def index
    @users = User.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @users }
    end
  end
 
  def new
    @user = User.new
  end

  def create
    @user = User.new(params[:user])

    @user.add_role('user')
    # Saving without session maintenance to skip
    # auto-login which can't happen here because
    # the User has not yet been activated
    if @user.save  && verify_recaptcha(:model => @user, :message => "Oh! It's error with reCAPTCHA!")
      flash[:notice] = "Your account has been created."
      redirect_to inbox_url
    else
      flash[:error] = "There was a problem creating you."
      render :action => :new
    end
  end

  def add_admin
    @user = User.find(params[:id])
    if @user.admin?
      flash[:warning] = "User already has Admin role"  
    elsif !@user.admin? && @user.add_role('admin') && @user.save
      flash[:notice] = "Admin role added"
    else
      flash[:error] = "Something went wrong"
    end 
  end

  def remove_admin
    @user = User.find(params[:id])
    if @user.remove_role('admin') && @user.save
      flash[:notice] = "Admin role removed"
    else
      flash[:error] = "Something went wrong"  
    end
  end


  def show
    @user = User.find(params[:id])
  end

  def edit
    @user = User.find(params[:id])
  end

  def myprofile
    @user = User.find(:all, :conditions => {:email => current_user.email})
  end

  def update
    @user = User.find(params[:id])
    if @user.update_attributes(params[:user])
      flash[:notice] = "Account updated!"
      redirect_to user_url
    else
      render :action => :edit
    end
  end
  
  def destroy
    @user = User.find(params[:id])
    @user.destroy
  end
  
end