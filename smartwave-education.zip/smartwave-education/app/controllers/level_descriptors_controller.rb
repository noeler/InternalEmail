class LevelDescriptorsController < ApplicationController

   before_filter :require_user
    include CsvMapper

  # GET /level_descriptors
  # GET /level_descriptors.json
  def index
    @level_descriptors = LevelDescriptor.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @level_descriptors }
    end
  end

  # GET /level_descriptors/1
  # GET /level_descriptors/1.json
  def show
    @level_descriptor = LevelDescriptor.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @level_descriptor }
    end
  end

  # GET /level_descriptors/new
  # GET /level_descriptors/new.json
  def new
    @level_descriptor = LevelDescriptor.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @level_descriptor }
    end
  end

  # GET /level_descriptors/1/edit
  def edit
    @level_descriptor = LevelDescriptor.find(params[:id])
  end

  # POST /level_descriptors
  # POST /level_descriptors.json
  def create
    @level_descriptor = LevelDescriptor.new(params[:level_descriptor])

    respond_to do |format|
      if @level_descriptor.save
        format.html { redirect_to @level_descriptor, notice: 'Level descriptor was successfully created.' }
        format.json { render json: @level_descriptor, status: :created, location: @level_descriptor }
      else
        format.html { render action: "new" }
        format.json { render json: @level_descriptor.errors, status: :unprocessable_entity }
      end
    end
  end

  # PUT /level_descriptors/1
  # PUT /level_descriptors/1.json
  def update
    @level_descriptor = LevelDescriptor.find(params[:id])

    respond_to do |format|
      if @level_descriptor.update_attributes(params[:level_descriptor])
        format.html { redirect_to @level_descriptor, notice: 'Level descriptor was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @level_descriptor.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /level_descriptors/1
  # DELETE /level_descriptors/1.json
  def destroy
    @level_descriptor = LevelDescriptor.find(params[:id])
    @level_descriptor.destroy

    respond_to do |format|
      format.html { redirect_to level_descriptors_url }
      format.json { head :no_content }
    end
  end
  
  def delete_all
    LevelDescriptor.delete_all
    
    respond_to do |format|
      format.html { redirect_to level_descriptors_url, notice: 'All level descriptors deleted' }
      format.json { head :no_content }
    end
  end
  
   def import
    @files = Dir.entries("public/uploads")
    
    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @level_descriptor}
    end
  end
   
  def import_file
    results = CsvMapper.import('public/uploads/' + params[:datafile]) do
      map_to LevelDescriptor # Map to the Person ActiveRecord class (defined above) instead of the default OpenStruct.
      after_row lambda{|row, leveldescriptor| leveldescriptor.save }  # Call this lambda and save each record after it's parsed.#

      start_at_row 1
      [level,keystage,subject,statement]
    end
    
    respond_to do |format|
      format.html { redirect_to level_descriptors_url, notice: 'Level descriptors imported successfully.' }
    end
    
  end

end
