class RegistrationGroupsController < ApplicationController
   before_filter :require_user
 # GET /registration_groups
  # GET /registration_groups.json
  def index
    @registration_groups = RegistrationGroup.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @registration_groups }
    end
  end

  # GET /registration_groups/1
  # GET /registration_groups/1.json
  def show
    @registration_group = RegistrationGroup.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @registration_group }
    end
  end

  # GET /registration_groups/new
  # GET /registration_groups/new.json
  def new
    @registration_group = RegistrationGroup.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @registration_group }
    end
  end

  # GET /registration_groups/1/edit
  def edit
    @registration_group = RegistrationGroup.find(params[:id])
  end

  # POST /registration_groups
  # POST /registration_groups.json
  def create
    @registration_group = RegistrationGroup.new(params[:registration_group])

    respond_to do |format|
      if @registration_group.save
        format.html { redirect_to @registration_group, notice: 'Registration group was successfully created.' }
        format.json { render json: @registration_group, status: :created, location: @registration_group }
      else
        format.html { render action: "new" }
        format.json { render json: @registration_group.errors, status: :unprocessable_entity }
      end
    end
  end

  # PUT /registration_groups/1
  # PUT /registration_groups/1.json
  def update
    @registration_group = RegistrationGroup.find(params[:id])

    respond_to do |format|
      if @registration_group.update_attributes(params[:registration_group])
        format.html { redirect_to @registration_group, notice: 'Registration group was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @registration_group.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /registration_groups/1
  # DELETE /registration_groups/1.json
  def destroy
    @registration_group = RegistrationGroup.find(params[:id])
    @registration_group.destroy

    respond_to do |format|
      format.html { redirect_to registration_groups_url }
      format.json { head :no_content }
    end
  end
  
   # GET /registration_groups/search
  # GET /registration_groups/search.json
  def search
    puts params[:q]
    
    query = ["%#{params[:q]}%"]
    sql = "registrationgroup LIKE ?" 
    @reggroups = RegistrationGroup.where([sql, *query])
    
    #@pupils = Pupil.where("forname LIKE ?", params[:q]) 

    respond_to do |format|
      #format.html # index.html.erb
      format.json { render json: @reggroups }
    end
  end
end
