class QrcodeController < ApplicationController

def qrcode
      @qrurl = "http://www.example.com"
      respond_to do |format|
       #format.html
       format.svg  { render :qrcode => @qrurl, :level => :l, :unit => 10 }
       format.png  { render :qrcode => @qrurl }
       format.gif  { render :qrcode => @qrurl }
       format.jpeg { render :qrcode => @qrurl }
      end
end
end