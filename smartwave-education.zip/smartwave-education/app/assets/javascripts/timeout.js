var timer;
var timer2;
 
$(function() {
  set_timeout();
  $(document).bind('mousemove click keypress scroll', reset_timer);
});
 
function reset_timer() {
  window.clearInterval(timer);
  set_timeout();
}
 
function set_timeout() {
  timer=setInterval("logout()",1000*60*20);	// 20 mins
  timer2=setInterval("showMessage()",1000*55*15); // 15 mins
}
 
function showMessage(){
	$('#TimeoutModal').modal({show:true});
}
 
function logout(){
  $.get('/timeout.json', function(force_logout){
    if (force_logout) {
      window.location = "/logout";
    }
  });
}