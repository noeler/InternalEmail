class Subject < ActiveRecord::Base
end
