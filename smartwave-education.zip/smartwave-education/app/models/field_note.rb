class FieldNote < ActiveRecord::Base
    attr_accessible :pupil, :level_descriptor, :subject, :red, :yellow, :green, :comment
end
