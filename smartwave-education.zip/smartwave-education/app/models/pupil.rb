class Pupil < ActiveRecord::Base
  attr_accessor :upload #, :level, :keystage, :subject, :statement

  def self.save(upload)
    name =  upload['datafile'].original_filename
    directory = "public/uploads"
    # create the file path
    path = File.join(directory, name)
    # write the file
    File.open(path, "wb") { |f| f.write(upload['datafile'].read) }
  end
end
