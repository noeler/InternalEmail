class RegistrationGroup < ActiveRecord::Base
end
