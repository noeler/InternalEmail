class User < ActiveRecord::Base
   validates :name, :presence => true, :length => { :minimum => 3 }
   validates :registration_code, :presence => true, :length => { :minimum => 3 }
   validates :email, :presence => true, :uniqueness => true, :length => {:minimum => 3}
   #add_index :email
      
   easy_roles :roles
   # Constant variable storing roles in the system, note dont change order just append new roles
 
   # Serialize roles as an array
   serialize :roles, Array

   # Create an empty roles array on create
   #before_validation_on_create :make_default_roles

   # Convenience method, is user an admin?
   def admin?
      has_role?("admin")
   end

   # Checks to see if a user has requested role
   def has_role?(role)
      roles.include?(role)
    end

   # Add a role to a user
   def add_role(role)
     self.roles << role
   end

   # Remove a role from a user
   def remove_role(role)
     self.roles.delete(role)
   end

   # Clear all users roles
   def clear_roles
     self.roles = []
   end

  acts_as_authentic do |c|
    c.login_field = 'email'
    c.logged_in_timeout(20.minutes) 
    c.transition_from_crypto_providers = Authlogic::CryptoProviders::Sha512,
    c.crypto_provider = Authlogic::CryptoProviders::SCrypt
  end
 
  private
  
  def make_default_roles
    clear_roles if roles.nil?
  end
end