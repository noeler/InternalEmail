class Level < ActiveRecord::Base
end
